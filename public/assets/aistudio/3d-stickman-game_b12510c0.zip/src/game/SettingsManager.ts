export type GraphicsQuality = 'low' | 'medium' | 'high';
export type ReticleStyle = 'dot' | 'crosshair';
export type ReticlePosition = 'center';

export interface GameSettings {
  volume: number; // 0 to 100
  graphics: GraphicsQuality;
  aimAssist: boolean;
  reticleStyle: ReticleStyle;
  reticlePosition?: ReticlePosition;
  cameraSensitivity: number; // 0.5 to 2.0 (default 1.0)
  cameraShake: boolean;
}

export const DEFAULT_SETTINGS: GameSettings = {
  volume: 75,
  graphics: 'high',
  aimAssist: true,
  reticleStyle: 'dot',
  reticlePosition: 'center',
  cameraSensitivity: 1.0,
  cameraShake: true,
};

class SettingsManager {
  private settings: GameSettings;
  private listeners: Set<(settings: GameSettings) => void> = new Set();

  constructor() {
    this.settings = { ...DEFAULT_SETTINGS };
    try {
      const saved = sessionStorage.getItem('stickman_settings');
      if (saved) {
        this.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {
      // Fallback to defaults
    }
  }

  public get(): GameSettings {
    return { ...this.settings };
  }

  public update(partial: Partial<GameSettings>): void {
    this.settings = { ...this.settings, ...partial };
    try {
      sessionStorage.setItem('stickman_settings', JSON.stringify(this.settings));
    } catch {
      // Ignore
    }
    this.listeners.forEach((listener) => listener(this.settings));
  }

  public subscribe(listener: (settings: GameSettings) => void): () => void {
    this.listeners.add(listener);
    listener(this.settings);
    return () => {
      this.listeners.delete(listener);
    };
  }
}

export const settingsManager = new SettingsManager();
