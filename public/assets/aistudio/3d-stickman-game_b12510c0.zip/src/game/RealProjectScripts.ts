/**
 * Real Project Scripts Catalog
 * Uses Vite's ?raw import to load the EXACT, UNTRUNCATED, authentic source files
 * directly from the project directory.
 */

// Import raw source code of authentic project files
import agathaSource from './AgathaAbilities.ts?raw';
import ironManSource from './IronManAbilities.ts?raw';
import stickmanRigSource from './StickmanRig.ts?raw';
import animControllerSource from './AnimationController.ts?raw';
import targetDummySource from './TargetDummy.ts?raw';
import projectileSource from './ProjectileSystem.ts?raw';
import gameSceneSource from './GameScene.ts?raw';
import audioSystemSource from './AudioSystem.ts?raw';
import settingsManagerSource from './SettingsManager.ts?raw';
import combatButtonsSource from '../components/CombatButtons.tsx?raw';
import virtualJoystickSource from '../components/VirtualJoystick.tsx?raw';
import aimReticleSource from '../components/AimReticle.tsx?raw';
import appSource from '../App.tsx?raw';

export interface ProjectScriptInfo {
  id: string;
  name: string;
  filePath: string;
  category:
    | 'Agatha'
    | 'Iron Man'
    | 'Characters'
    | 'Target System'
    | 'Combat & Interactions'
    | 'Movement & Camera'
    | 'Audio & Sound'
    | 'UI & Controls'
    | 'Settings & State';
  summary: string;
  originalSource: string;
  fileExtension: 'ts' | 'tsx';
}

export function getEffectiveScriptSource(scriptId: string, defaultSource: string): string {
  try {
    const saved = localStorage.getItem(`script_source_${scriptId}`);
    if (saved) return saved;
  } catch {
    // ignore
  }
  return defaultSource;
}

export const PROJECT_SCRIPTS: ProjectScriptInfo[] = [
  {
    id: 'agatha-abilities',
    name: 'Agatha Harkness Dark Magic',
    filePath: '/src/game/AgathaAbilities.ts',
    category: 'Agatha',
    summary:
      'Implements Agatha Harkness magical abilities: Arcane Blast projectile, 3-second Dark Drain health siphon tendrils, directional Shadow Step teleportation, Arcane Flight levitation, and Arcane Choke telekinetic suspension.',
    originalSource: getEffectiveScriptSource('agatha-abilities', agathaSource),
    fileExtension: 'ts',
  },
  {
    id: 'ironman-abilities',
    name: 'Iron Man Armor Systems & Abilities',
    filePath: '/src/game/IronManAbilities.ts',
    category: 'Iron Man',
    summary:
      'Implements Iron Man weapon systems: Repulsor blasts, Bezier curve micro-missile volleys, continuous Dual Beam, Beam Clash interactive tug-of-war mechanic, Heavy Missile/Unibeam, and 360-degree Spinning Lasers.',
    originalSource: getEffectiveScriptSource('ironman-abilities', ironManSource),
    fileExtension: 'ts',
  },
  {
    id: 'target-dummy',
    name: 'Target Dummy & Training Systems',
    filePath: '/src/game/TargetDummy.ts',
    category: 'Target System',
    summary:
      'Interactive clay training dummies with spring recoil physics, dynamic billboarded health bars, hit flashes, particle destruction triggers, automatic respawning, and Rival Dummy beam-clash counterattacks.',
    originalSource: getEffectiveScriptSource('target-dummy', targetDummySource),
    fileExtension: 'ts',
  },
  {
    id: 'stickman-rig',
    name: 'R15 Articulated Stickman Rig',
    filePath: '/src/game/StickmanRig.ts',
    category: 'Characters',
    summary:
      'Constructs the white clay porcelain humanoid model featuring an articulated R15 joint hierarchy (pelvis, waist, torso, neck, limbs, palms, feet, contact shadow) and dual hand/foot thruster jet flares.',
    originalSource: getEffectiveScriptSource('stickman-rig', stickmanRigSource),
    fileExtension: 'ts',
  },
  {
    id: 'animation-controller',
    name: 'Animation Controller & Kinematics',
    filePath: '/src/game/AnimationController.ts',
    category: 'Characters',
    summary:
      'Controls character kinematics: procedural walking cycle, idle breathing, attack casting arm poses, repulsor aiming pitch, flight hover bank angles, dash lean, and channeled ability stances.',
    originalSource: getEffectiveScriptSource('animation-controller', animControllerSource),
    fileExtension: 'ts',
  },
  {
    id: 'projectile-system',
    name: 'Projectile & Particle System',
    filePath: '/src/game/ProjectileSystem.ts',
    category: 'Combat & Interactions',
    summary:
      'Simulates classic projectile trajectories, guided homing calculations, hit confirmation feedback, 3D floating damage number projections, and stylized collision particle bursts.',
    originalSource: getEffectiveScriptSource('projectile-system', projectileSource),
    fileExtension: 'ts',
  },
  {
    id: 'game-scene',
    name: '3D Scene, Loop & Physics Arena',
    filePath: '/src/game/GameScene.ts',
    category: 'Movement & Camera',
    summary:
      'Core Three.js orchestration: WebGL renderer, studio lighting, baseplate, testing structures, bounding box collisions, player input integration, over-the-shoulder follow camera, and aim assist raycasting.',
    originalSource: getEffectiveScriptSource('game-scene', gameSceneSource),
    fileExtension: 'ts',
  },
  {
    id: 'audio-system',
    name: 'Web Audio Procedural Sound Engine',
    filePath: '/src/game/AudioSystem.ts',
    category: 'Audio & Sound',
    summary:
      'Pure Web Audio API procedural synthesis: repulsor zaps, missile explosions, arcane dark magic whooshes, shadow step rumbles, beam clash crackles, thruster engine hums, and UI clicks without external audio files.',
    originalSource: getEffectiveScriptSource('audio-system', audioSystemSource),
    fileExtension: 'ts',
  },
  {
    id: 'settings-manager',
    name: 'Game Settings & Persistence',
    filePath: '/src/game/SettingsManager.ts',
    category: 'Settings & State',
    summary:
      'State management for graphics quality (shadows, pixel ratios), reticle style, camera sensitivity, camera shake toggle, and master volume with reactive subscriber dispatching.',
    originalSource: getEffectiveScriptSource('settings-manager', settingsManagerSource),
    fileExtension: 'ts',
  },
  {
    id: 'combat-buttons',
    name: 'Combat HUD & Ability Buttons',
    filePath: '/src/components/CombatButtons.tsx',
    category: 'UI & Controls',
    summary:
      'Touch-friendly mobile combat interface featuring a primary attack button surrounded by a radial semicircle of 4 character abilities, dynamic SVG cooldown rings, dash, flight toggle, and beam clash tap indicators.',
    originalSource: getEffectiveScriptSource('combat-buttons', combatButtonsSource),
    fileExtension: 'tsx',
  },
  {
    id: 'virtual-joystick',
    name: 'Analog Virtual Joystick',
    filePath: '/src/components/VirtualJoystick.tsx',
    category: 'UI & Controls',
    summary:
      'Bottom-left analog touchscreen joystick with dynamic base centering, thumb clamping, deadzone filtering, and normalized directional vector dispatching.',
    originalSource: getEffectiveScriptSource('virtual-joystick', virtualJoystickSource),
    fileExtension: 'tsx',
  },
  {
    id: 'aim-reticle',
    name: 'Aim Reticle & Screen Projections',
    filePath: '/src/components/AimReticle.tsx',
    category: 'UI & Controls',
    summary:
      'Central target reticle, smooth animated target-lock corner brackets around detected dummies, Marvel Rivals-style hit confirmation flashes, and 3D-to-2D projected damage counters.',
    originalSource: getEffectiveScriptSource('aim-reticle', aimReticleSource),
    fileExtension: 'tsx',
  },
  {
    id: 'app-main',
    name: 'Main Application Entry & Bridge',
    filePath: '/src/App.tsx',
    category: 'UI & Controls',
    summary:
      'Top-level React application root orchestrating mode switching, touch orbit listeners, modal popups (Power Selection, Color Customizer, Settings), and full-screen landscape orientation.',
    originalSource: getEffectiveScriptSource('app-main', appSource),
    fileExtension: 'tsx',
  },
];
