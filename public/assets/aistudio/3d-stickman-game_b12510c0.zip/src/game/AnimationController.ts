import * as THREE from 'three';
import { StickmanNodes } from './StickmanRig';

export class AnimationController {
  private nodes: StickmanNodes;
  private walkPhase: number = 0;
  private idleTime: number = 0;
  private walkBlend: number = 0; // 0 = idle, 1 = walk

  // Attack animation state
  private isAttacking: boolean = false;
  private attackTime: number = 0;
  private readonly attackDuration: number = 0.42;
  private attackAimPitch: number = 0;
  private attackReleased: boolean = false;
  private onAttackRelease: (() => void) | null = null;

  // Rapid repulsor arm-raising animation state
  private isRepulsorActive: boolean = false;
  private repulsorHand: 'left' | 'right' = 'right';
  private repulsorTime: number = 0;
  private readonly repulsorDuration: number = 0.22;
  private repulsorPitch: number = 0;

  // Sustained ability poses (Iron Man & Agatha Harkness)
  public dualBeamActive: boolean = false;
  public dualBeamPitch: number = 0;
  public spinningLasersActive: boolean = false;
  public darkDrainActive: boolean = false;
  public arcaneChokeActive: boolean = false;
  public isAgatha: boolean = false;

  // Flight & Dash locomotion states
  public isFlying: boolean = false;
  public flightBlend: number = 0; // 0 = ground, 1 = flying
  public flightRoll: number = 0; // banking into turns
  public isDashing: boolean = false;

  // Base pelvis height when standing
  private readonly basePelvisY: number = 1.15;

  constructor(nodes: StickmanNodes) {
    this.nodes = nodes;
  }

  public triggerRepulsor(hand: 'left' | 'right', aimPitch: number): void {
    this.isRepulsorActive = true;
    this.repulsorHand = hand;
    this.repulsorTime = 0;
    this.repulsorPitch = THREE.MathUtils.clamp(aimPitch, -0.6, 0.6);
  }

  public triggerAttack(aimPitch: number, onRelease: () => void): void {
    this.isAttacking = true;
    this.attackTime = 0;
    this.attackAimPitch = THREE.MathUtils.clamp(aimPitch, -0.6, 0.6);
    this.attackReleased = false;
    this.onAttackRelease = onRelease;
  }

  public getIsAttacking(): boolean {
    return this.isAttacking;
  }

  /**
   * Updates animations based on character speed and delta time.
   */
  public update(dt: number, speed: number): void {
    this.idleTime += dt;

    // Smoothly blend between Idle, Walk, and Flight states
    const targetWalkBlend = (!this.isFlying && speed > 0.04) ? Math.min(1.0, speed) : 0;
    const blendSpeed = targetWalkBlend > this.walkBlend ? 8.0 : 6.0;
    this.walkBlend = THREE.MathUtils.damp(this.walkBlend, targetWalkBlend, blendSpeed, dt);

    const targetFlightBlend = this.isFlying ? 1.0 : 0.0;
    this.flightBlend = THREE.MathUtils.damp(this.flightBlend, targetFlightBlend, 9.0, dt);

    // Advance walk cycle phase proportional to actual movement speed
    if (this.walkBlend > 0.001) {
      const cadence = 7.8 * Math.max(0.3, speed);
      this.walkPhase += cadence * dt;
    }

    const t = this.idleTime;
    const phi = this.walkPhase;
    const blend = this.walkBlend;
    const invBlend = 1 - blend;

    // ==========================================
    // 1. IDLE BASE POSE
    // ==========================================
    const breath = Math.sin(t * 1.7);
    const slowSway = Math.sin(t * 0.8);

    const idlePelvisY = this.basePelvisY + breath * 0.008;
    const idlePelvisX = slowSway * 0.006;
    const idlePelvisRotZ = slowSway * 0.012;
    const idlePelvisRotY = slowSway * 0.015;

    // Torso breathing: subtle chest pitch
    const idleWaistRotX = -breath * 0.025;
    const idleWaistRotY = -idlePelvisRotY * 0.5;
    const idleWaistRotZ = -idlePelvisRotZ * 0.5;

    // Head idle
    const idleHeadRotX = breath * 0.018;
    const idleHeadRotY = -slowSway * 0.02;

    // Arms idle (hanging down with slight relaxation):
    // Left arm (-X) abducts outward (-Z rotation)
    const idleLeftShoulderRotX = breath * 0.025;
    const idleLeftShoulderRotZ = -0.12 - breath * 0.015;
    const idleLeftElbowRotX = 0.22 - breath * 0.02;

    // Right arm (+X) abducts outward (+Z rotation)
    const idleRightShoulderRotX = breath * 0.025;
    const idleRightShoulderRotZ = 0.12 + breath * 0.015;
    const idleRightElbowRotX = 0.22 - breath * 0.02;

    // Legs idle: grounded
    const idleLeftHipRotX = 0.0;
    const idleLeftKneeRotX = 0.0;
    const idleLeftAnkleRotX = 0.0;

    const idleRightHipRotX = 0.0;
    const idleRightKneeRotX = 0.0;
    const idleRightAnkleRotX = 0.0;

    // ==========================================
    // 2. WALKING BASE POSE (Facing -Z)
    // ==========================================
    // Pelvis walk: vertical bounce and lateral weight transfer
    const walkBounce = -0.032 * Math.abs(Math.sin(phi));
    const walkPelvisY = this.basePelvisY + walkBounce;
    const walkPelvisX = Math.sin(phi) * 0.020;
    const walkPelvisRotY = -Math.sin(phi) * 0.08;
    const walkPelvisRotZ = Math.sin(phi) * 0.025;

    // Upper torso forward lean (-0.06 rad toward -Z) and counter-twist
    const walkWaistRotX = -0.06;
    const walkWaistRotY = Math.sin(phi) * 0.09;
    const walkWaistRotZ = -Math.sin(phi) * 0.02;

    // Head balances counter-twist
    const walkHeadRotX = 0.03;
    const walkHeadRotY = -walkWaistRotY * 0.5;

    // Leg stride: positive rotX swings leg forward (-Z)
    const strideAmp = 0.56;
    
    // Right Leg (+X)
    const walkRightHipRotX = Math.sin(phi) * strideAmp;
    // Knee bends backward (+Z) during forward swing phase -> negative rotX
    const rightSwing = Math.max(0, Math.sin(phi + 0.35));
    const walkRightKneeRotX = -Math.pow(rightSwing, 1.8) * 0.85;
    const walkRightAnkleRotX = Math.sin(phi) * 0.20 - 0.05;

    // Left Leg (-X) (opposite phase)
    const walkLeftHipRotX = -Math.sin(phi) * strideAmp;
    const leftSwing = Math.max(0, -Math.sin(phi - 0.35));
    const walkLeftKneeRotX = -Math.pow(leftSwing, 1.8) * 0.85;
    const walkLeftAnkleRotX = -Math.sin(phi) * 0.20 - 0.05;

    // Arms: coordinated opposite to legs
    const armSwingAmp = 0.50;
    // Right arm swings backward when right leg swings forward
    const walkRightShoulderRotX = -Math.sin(phi) * armSwingAmp;
    const walkRightShoulderRotZ = 0.14;
    const walkRightElbowRotX = 0.28 + Math.max(0, -Math.sin(phi)) * 0.36;

    // Left arm swings forward when right leg swings forward
    const walkLeftShoulderRotX = Math.sin(phi) * armSwingAmp;
    const walkLeftShoulderRotZ = -0.14;
    const walkLeftElbowRotX = 0.28 + Math.max(0, Math.sin(phi)) * 0.36;

    const leftWristRotX = Math.cos(phi) * 0.12;
    const rightWristRotX = -Math.cos(phi) * 0.12;

    // Base blended rotations for locomotion
    const n = this.nodes;

    n.pelvis.position.y = idlePelvisY * invBlend + walkPelvisY * blend;
    n.pelvis.position.x = idlePelvisX * invBlend + walkPelvisX * blend;
    n.pelvis.rotation.y = idlePelvisRotY * invBlend + walkPelvisRotY * blend;
    n.pelvis.rotation.z = idlePelvisRotZ * invBlend + walkPelvisRotZ * blend;

    let targetWaistRotX = idleWaistRotX * invBlend + walkWaistRotX * blend;
    let targetWaistRotY = idleWaistRotY * invBlend + walkWaistRotY * blend;
    let targetWaistRotZ = idleWaistRotZ * invBlend + walkWaistRotZ * blend;

    let targetHeadRotX = idleHeadRotX * invBlend + walkHeadRotX * blend;
    let targetHeadRotY = idleHeadRotY * invBlend + walkHeadRotY * blend;

    // Left Arm
    n.leftShoulder.rotation.x = idleLeftShoulderRotX * invBlend + walkLeftShoulderRotX * blend;
    n.leftShoulder.rotation.z = idleLeftShoulderRotZ * invBlend + walkLeftShoulderRotZ * blend;
    n.leftElbow.rotation.x = idleLeftElbowRotX * invBlend + walkLeftElbowRotX * blend;
    n.leftWrist.rotation.x = leftWristRotX * blend;

    // Right Arm base
    let targetRightShoulderRotX = idleRightShoulderRotX * invBlend + walkRightShoulderRotX * blend;
    let targetRightShoulderRotY = 0;
    let targetRightShoulderRotZ = idleRightShoulderRotZ * invBlend + walkRightShoulderRotZ * blend;
    let targetRightElbowRotX = idleRightElbowRotX * invBlend + walkRightElbowRotX * blend;
    let targetRightWristRotX = rightWristRotX * blend;

    // Legs
    n.leftHip.rotation.x = idleLeftHipRotX * invBlend + walkLeftHipRotX * blend;
    n.leftKnee.rotation.x = idleLeftKneeRotX * invBlend + walkLeftKneeRotX * blend;
    n.leftAnkle.rotation.x = idleLeftAnkleRotX * invBlend + walkLeftAnkleRotX * blend;

    n.rightHip.rotation.x = idleRightHipRotX * invBlend + walkRightHipRotX * blend;
    n.rightKnee.rotation.x = idleRightKneeRotX * invBlend + walkRightKneeRotX * blend;
    n.rightAnkle.rotation.x = idleRightAnkleRotX * invBlend + walkRightAnkleRotX * blend;

    // Flight & Dash Layer blending
    const fb = this.flightBlend;
    if (fb > 0.001) {
      // In flight, legs extend straight/softly backward with toes pointed down
      const flightLegPitch = -0.30 - (this.isDashing ? 0.40 : speed * 0.25);
      n.leftHip.rotation.x = THREE.MathUtils.lerp(n.leftHip.rotation.x, flightLegPitch, fb);
      n.rightHip.rotation.x = THREE.MathUtils.lerp(n.rightHip.rotation.x, flightLegPitch, fb);
      n.leftKnee.rotation.x = THREE.MathUtils.lerp(n.leftKnee.rotation.x, -0.12, fb);
      n.rightKnee.rotation.x = THREE.MathUtils.lerp(n.rightKnee.rotation.x, -0.12, fb);
      n.leftAnkle.rotation.x = THREE.MathUtils.lerp(n.leftAnkle.rotation.x, 0.42, fb);
      n.rightAnkle.rotation.x = THREE.MathUtils.lerp(n.rightAnkle.rotation.x, 0.42, fb);

      // In flight without active arms/beams, arms hold dynamic flight stabilization / thruster pose
      if (!this.isAttacking && !this.isRepulsorActive && !this.dualBeamActive && !this.spinningLasersActive) {
        const armFlightX = -0.32 - (this.isDashing ? 0.50 : speed * 0.28);
        n.leftShoulder.rotation.x = THREE.MathUtils.lerp(n.leftShoulder.rotation.x, armFlightX, fb);
        n.leftShoulder.rotation.z = THREE.MathUtils.lerp(n.leftShoulder.rotation.z, -0.22, fb);
        n.leftElbow.rotation.x = THREE.MathUtils.lerp(n.leftElbow.rotation.x, 0.16, fb);
        n.leftWrist.rotation.x = THREE.MathUtils.lerp(n.leftWrist.rotation.x, -0.22, fb);

        targetRightShoulderRotX = THREE.MathUtils.lerp(targetRightShoulderRotX, armFlightX, fb);
        targetRightShoulderRotZ = THREE.MathUtils.lerp(targetRightShoulderRotZ, 0.22, fb);
        targetRightElbowRotX = THREE.MathUtils.lerp(targetRightElbowRotX, 0.16, fb);
        targetRightWristRotX = THREE.MathUtils.lerp(targetRightWristRotX, -0.22, fb);
      }

      // Torso leans forward into flight direction, head balances forward
      const forwardLean = -0.34 * (this.isDashing ? 1.5 : Math.max(0.2, speed));
      targetWaistRotX = THREE.MathUtils.lerp(targetWaistRotX, forwardLean, fb);
      targetHeadRotX = THREE.MathUtils.lerp(targetHeadRotX, -forwardLean * 0.75, fb);

      // Roll/banking into turns
      n.pelvis.rotation.z += this.flightRoll * fb;
      targetWaistRotZ += this.flightRoll * 0.45 * fb;
    }

    // ==========================================
    // 3. ATTACK ANIMATION LAYER (Casting Hand Thrust)
    // ==========================================
    if (this.isAttacking) {
      this.attackTime += dt;
      const progress = this.attackTime / this.attackDuration;

      // Projectile release point at ~28% of attack duration
      if (this.attackTime >= 0.12 && !this.attackReleased) {
        this.attackReleased = true;
        if (this.onAttackRelease) {
          this.onAttackRelease();
        }
      }

      let attackWeight = 0;
      if (progress < 0.28) {
        // Anticipation: right arm pulls backward (negative rotX)
        const p = progress / 0.28;
        attackWeight = Math.sin(p * Math.PI * 0.5);
        targetRightShoulderRotX = THREE.MathUtils.lerp(targetRightShoulderRotX, -0.45, attackWeight);
        targetRightShoulderRotZ = THREE.MathUtils.lerp(targetRightShoulderRotZ, 0.28, attackWeight);
        targetRightElbowRotX = THREE.MathUtils.lerp(targetRightElbowRotX, 1.25, attackWeight);
        targetWaistRotY -= 0.18 * attackWeight;
        targetWaistRotX += 0.06 * attackWeight;
      } else if (progress < 0.55) {
        // Forward cast thrust toward aim elevation (positive rotX)
        const p = (progress - 0.28) / 0.27;
        attackWeight = 1.0;
        const castArmX = 1.48 + this.attackAimPitch;
        targetRightShoulderRotX = THREE.MathUtils.lerp(-0.45, castArmX, p);
        targetRightShoulderRotY = 0.12;
        targetRightShoulderRotZ = 0.05;
        targetRightElbowRotX = THREE.MathUtils.lerp(1.25, 0.08, p); // elbow straightens out
        targetRightWristRotX = -0.20;
        targetWaistRotY += 0.24 * p;
        targetWaistRotX -= 0.10 * p;
        targetHeadRotX += this.attackAimPitch * 0.4;
      } else if (progress <= 1.0) {
        // Smooth recovery back to locomotion
        const p = (progress - 0.55) / 0.45;
        const decay = 1 - Math.sin(p * Math.PI * 0.5);
        const castArmX = 1.48 + this.attackAimPitch;
        targetRightShoulderRotX = THREE.MathUtils.lerp(targetRightShoulderRotX, castArmX, decay);
        targetRightShoulderRotY = THREE.MathUtils.lerp(0, 0.12, decay);
        targetRightShoulderRotZ = THREE.MathUtils.lerp(targetRightShoulderRotZ, 0.05, decay);
        targetRightElbowRotX = THREE.MathUtils.lerp(targetRightElbowRotX, 0.08, decay);
        targetWaistRotY += 0.24 * decay;
      } else {
        this.isAttacking = false;
      }
    }

    // Fast repulsor arm-raising animation
    if (this.isRepulsorActive) {
      this.repulsorTime += dt;
      if (this.repulsorTime >= this.repulsorDuration) {
        this.isRepulsorActive = false;
      } else {
        const p = this.repulsorTime / this.repulsorDuration;
        const w = Math.sin(p * Math.PI); // Smooth surge and drop
        if (this.repulsorHand === 'right') {
          targetRightShoulderRotX = THREE.MathUtils.lerp(targetRightShoulderRotX, 1.48 + this.repulsorPitch, w);
          targetRightShoulderRotY = THREE.MathUtils.lerp(targetRightShoulderRotY, 0.08, w);
          targetRightShoulderRotZ = THREE.MathUtils.lerp(targetRightShoulderRotZ, 0.06, w);
          targetRightElbowRotX = THREE.MathUtils.lerp(targetRightElbowRotX, 0.08, w);
          targetRightWristRotX = THREE.MathUtils.lerp(targetRightWristRotX, -0.22, w);
          targetWaistRotY += 0.08 * w;
        } else {
          n.leftShoulder.rotation.x = THREE.MathUtils.lerp(n.leftShoulder.rotation.x, 1.48 + this.repulsorPitch, w);
          n.leftShoulder.rotation.y = THREE.MathUtils.lerp(n.leftShoulder.rotation.y, -0.08, w);
          n.leftShoulder.rotation.z = THREE.MathUtils.lerp(n.leftShoulder.rotation.z, -0.06, w);
          n.leftElbow.rotation.x = THREE.MathUtils.lerp(n.leftElbow.rotation.x, 0.08, w);
          n.leftWrist.rotation.x = THREE.MathUtils.lerp(n.leftWrist.rotation.x, -0.22, w);
          targetWaistRotY -= 0.08 * w;
        }
      }
    }

    // ==========================================
    // 4. SUSTAINED ABILITY POSES (Dual-Hand Beam & Spinning Lasers)
    // ==========================================
    if (this.dualBeamActive) {
      // Both arms thrust forward in unison
      const beamElev = this.dualBeamPitch;
      targetRightShoulderRotX = 1.48 + beamElev;
      targetRightShoulderRotY = 0.05;
      targetRightShoulderRotZ = 0.06;
      targetRightElbowRotX = 0.06;
      targetRightWristRotX = -0.15;

      n.leftShoulder.rotation.x = 1.48 + beamElev;
      n.leftShoulder.rotation.y = -0.05;
      n.leftShoulder.rotation.z = -0.06;
      n.leftElbow.rotation.x = 0.06;
      n.leftWrist.rotation.x = -0.15;

      targetWaistRotX = -0.08;
      targetHeadRotX = beamElev * 0.4;
    } else if (this.spinningLasersActive) {
      // Extended T-pose combat stance for spinning lasers
      targetRightShoulderRotX = 0;
      targetRightShoulderRotY = 0;
      targetRightShoulderRotZ = 1.50; // straight right
      targetRightElbowRotX = 0.02;

      n.leftShoulder.rotation.x = 0;
      n.leftShoulder.rotation.y = 0;
      n.leftShoulder.rotation.z = -1.50; // straight left
      n.leftElbow.rotation.x = 0.02;
    } else if (this.darkDrainActive) {
      // Both hands raised outward in a menacing siphoning pose with undulating fingers
      const drainPulse = Math.sin(t * 14) * 0.08;
      targetRightShoulderRotX = 1.38 + drainPulse;
      targetRightShoulderRotY = 0.25;
      targetRightShoulderRotZ = 0.35;
      targetRightElbowRotX = 0.35;
      targetRightWristRotX = -0.30;

      n.leftShoulder.rotation.x = 1.38 + drainPulse;
      n.leftShoulder.rotation.y = -0.25;
      n.leftShoulder.rotation.z = -0.35;
      n.leftElbow.rotation.x = 0.35;
      n.leftWrist.rotation.x = -0.30;

      targetWaistRotX = -0.15;
      targetHeadRotX = 0.18;
    } else if (this.arcaneChokeActive) {
      // Both hands held forward in a powerful telekinetic choke-grip pose
      const chokeTremor = (Math.random() - 0.5) * 0.04;
      targetRightShoulderRotX = 1.58 + chokeTremor;
      targetRightShoulderRotY = 0.08;
      targetRightShoulderRotZ = 0.14;
      targetRightElbowRotX = 0.12;
      targetRightWristRotX = -0.38;

      n.leftShoulder.rotation.x = 1.58 - chokeTremor;
      n.leftShoulder.rotation.y = -0.08;
      n.leftShoulder.rotation.z = -0.14;
      n.leftElbow.rotation.x = 0.12;
      n.leftWrist.rotation.x = -0.38;

      targetWaistRotX = -0.05;
      targetHeadRotX = 0.22;
    }

    // Apply upper body rotations
    n.waistJoint.rotation.x = targetWaistRotX;
    n.waistJoint.rotation.y = targetWaistRotY;
    n.waistJoint.rotation.z = targetWaistRotZ;

    n.head.rotation.x = targetHeadRotX;
    n.head.rotation.y = targetHeadRotY;

    n.rightShoulder.rotation.x = targetRightShoulderRotX;
    n.rightShoulder.rotation.y = targetRightShoulderRotY;
    n.rightShoulder.rotation.z = targetRightShoulderRotZ;
    n.rightElbow.rotation.x = targetRightElbowRotX;
    n.rightWrist.rotation.x = targetRightWristRotX;

    // Contact shadow
    const shadowScale = 1.0 - (n.pelvis.position.y - this.basePelvisY) * 1.5;
    n.contactShadow.scale.set(shadowScale, shadowScale, 1.0);
  }
}
