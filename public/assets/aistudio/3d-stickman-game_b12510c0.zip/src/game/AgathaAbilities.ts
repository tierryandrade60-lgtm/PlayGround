import * as THREE from 'three';
import { TargetDummy } from './TargetDummy';
import { StickmanNodes } from './StickmanRig';
import { audioSystem } from './AudioSystem';

export interface ArcaneBolt {
  mesh: THREE.Group;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  startPos: THREE.Vector3;
  maxRange: number;
  target: TargetDummy | null;
  homingStrength: number;
  isDead: boolean;
}

export interface DarkDrainTendril {
  target: TargetDummy;
  line: THREE.Line;
  glow: THREE.Mesh;
  particles: { progress: number; speed: number; mesh: THREE.Mesh }[];
}

export interface ArcaneChokeState {
  active: boolean;
  target: TargetDummy | null;
  timer: number;
  maxDuration: number;
  tickTimer: number;
  leftCord: THREE.Line | null;
  rightCord: THREE.Line | null;
  neckCoil: THREE.Mesh | null;
  chokeLight: THREE.PointLight | null;
}

export interface RunicDecal {
  mesh: THREE.Mesh;
  ring: THREE.Mesh;
  light: THREE.PointLight;
  age: number;
  maxAge: number;
}

export class AgathaAbilities {
  private scene: THREE.Scene;
  private stickman: StickmanNodes;
  private getAimDestination: () => { pos: THREE.Vector3; target: TargetDummy | null };
  private onDamageDealt: (dummy: TargetDummy, dmg: number, hitPos: THREE.Vector3, knockback?: THREE.Vector3) => void;
  private onShake: (amount: number) => void;
  public onArcaneCast?: (hand: 'left' | 'right', aimPitch: number) => void;
  private currentHand: 'left' | 'right' = 'right';

  // Active projectiles & effects
  private arcaneBolts: ArcaneBolt[] = [];
  private runicDecals: RunicDecal[] = [];
  private smokeParticles: { pos: THREE.Vector3; vel: THREE.Vector3; age: number; maxAge: number; size: number; colorHex: number }[] = [];
  private smokeInstancedMesh: THREE.InstancedMesh;
  private dummyMatrix = new THREE.Matrix4();

  // Dark Drain state (Exact 3.0s duration)
  public isDarkDrainActive: boolean = false;
  private darkDrainTimer: number = 0;
  private readonly darkDrainDuration: number = 3.0;
  private darkDrainTickTimer: number = 0;
  private activeDrainTendrils: Map<number, DarkDrainTendril> = new Map();
  private drainChestOrb: THREE.Mesh;
  private drainChestLight: THREE.PointLight;

  // Arcane Choke state (Exact 3.0s duration)
  public chokeState: ArcaneChokeState = {
    active: false,
    target: null,
    timer: 0,
    maxDuration: 3.0,
    tickTimer: 0,
    leftCord: null,
    rightCord: null,
    neckCoil: null,
    chokeLight: null,
  };
  public chokeElevationOffset: number = 0;

  // Arcane Flight Visual Aura & Smoke
  public isArcaneFlightActive: boolean = false;
  private flightMistTimer: number = 0;
  private flightRingMesh: THREE.Mesh;

  // Reusable Runic Circle Texture
  private runicTexture: THREE.CanvasTexture;

  constructor(
    scene: THREE.Scene,
    stickman: StickmanNodes,
    getAimDestination: () => { pos: THREE.Vector3; target: TargetDummy | null },
    onDamageDealt: (dummy: TargetDummy, dmg: number, hitPos: THREE.Vector3, knockback?: THREE.Vector3) => void,
    onShake: (amount: number) => void
  ) {
    this.scene = scene;
    this.stickman = stickman;
    this.getAimDestination = getAimDestination;
    this.onDamageDealt = onDamageDealt;
    this.onShake = onShake;

    // 1. Generate Arcane Runic Circle Canvas Texture
    this.runicTexture = this.createRunicCanvasTexture();

    // 2. Dark Drain Chest Vortex Orb
    const orbGeo = new THREE.SphereGeometry(0.28, 16, 16);
    const orbMat = new THREE.MeshBasicMaterial({
      color: 0x9333ea,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.drainChestOrb = new THREE.Mesh(orbGeo, orbMat);
    this.drainChestOrb.visible = false;
    this.scene.add(this.drainChestOrb);

    this.drainChestLight = new THREE.PointLight(0xa855f7, 0, 8);
    this.scene.add(this.drainChestLight);

    // 3. Flight Mystical Ground/Leg Aura Ring
    const ringGeo = new THREE.RingGeometry(0.35, 0.75, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x7e22ce,
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.flightRingMesh = new THREE.Mesh(ringGeo, ringMat);
    this.flightRingMesh.rotation.x = -Math.PI / 2;
    this.flightRingMesh.visible = false;
    this.scene.add(this.flightRingMesh);

    // 4. Arcane Choke Visual Cords & Neck Coil
    this.initChokeMeshes();

    // 5. Pooled Dark Smoke/Ember Particles (Black & Deep Violet)
    const smokeGeo = new THREE.SphereGeometry(0.12, 8, 8);
    const smokeMat = new THREE.MeshBasicMaterial({
      color: 0x7e22ce,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    this.smokeInstancedMesh = new THREE.InstancedMesh(smokeGeo, smokeMat, 220);
    this.smokeInstancedMesh.count = 0;
    this.scene.add(this.smokeInstancedMesh);
  }

  private createRunicCanvasTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.clearRect(0, 0, 256, 256);

    const cx = 128;
    const cy = 128;

    // Glowing outer concentric rings
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(cx, cy, 118, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#c084fc';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, 108, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#9333ea';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(cx, cy, 75, 0, Math.PI * 2);
    ctx.stroke();

    // Arcane Octagram / Witch Sigil Points
    ctx.strokeStyle = 'rgba(216, 180, 254, 0.75)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4;
      const x1 = cx + Math.cos(a) * 108;
      const y1 = cy + Math.sin(a) * 108;
      const x2 = cx + Math.cos(a + Math.PI * 0.75) * 108;
      const y2 = cy + Math.sin(a + Math.PI * 0.75) * 108;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    // Mystical Glyphs / Runes along inner border
    ctx.fillStyle = '#f3e8ff';
    ctx.font = 'bold 15px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const runes = ['ᚦ', 'ᚱ', 'ᚲ', 'ᚷ', 'ᚹ', 'ᚺ', 'ᛃ', 'ᛈ', 'ᛉ', 'ᛋ', 'ᛏ', 'ᛒ'];
    for (let i = 0; i < 12; i++) {
      const a = (i * Math.PI) / 6;
      const rx = cx + Math.cos(a) * 92;
      const ry = cy + Math.sin(a) * 92;
      ctx.save();
      ctx.translate(rx, ry);
      ctx.rotate(a + Math.PI / 2);
      ctx.fillText(runes[i], 0, 0);
      ctx.restore();
    }

    // Inner Glowing Core
    const grad = ctx.createRadialGradient(cx, cy, 10, cx, cy, 65);
    grad.addColorStop(0, 'rgba(238, 210, 255, 0.85)');
    grad.addColorStop(0.5, 'rgba(147, 51, 234, 0.55)');
    grad.addColorStop(1, 'rgba(30, 10, 50, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, 65, 0, Math.PI * 2);
    ctx.fill();

    return new THREE.CanvasTexture(canvas);
  }

  private initChokeMeshes(): void {
    const cordMat = new THREE.LineBasicMaterial({
      color: 0xc084fc,
      linewidth: 3,
      transparent: true,
      opacity: 0.9,
    });
    const cordGeoL = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    const cordGeoR = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);

    this.chokeState.leftCord = new THREE.Line(cordGeoL, cordMat);
    this.chokeState.rightCord = new THREE.Line(cordGeoR, cordMat);
    this.chokeState.leftCord.visible = false;
    this.chokeState.rightCord.visible = false;
    this.scene.add(this.chokeState.leftCord);
    this.scene.add(this.chokeState.rightCord);

    // Glowing constriction Torus around throat
    const neckGeo = new THREE.TorusGeometry(0.32, 0.06, 8, 20);
    const neckMat = new THREE.MeshBasicMaterial({
      color: 0x9333ea,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.chokeState.neckCoil = new THREE.Mesh(neckGeo, neckMat);
    this.chokeState.neckCoil.rotation.x = Math.PI / 2;
    this.chokeState.neckCoil.visible = false;
    this.scene.add(this.chokeState.neckCoil);

    this.chokeState.chokeLight = new THREE.PointLight(0xa855f7, 0, 6);
    this.scene.add(this.chokeState.chokeLight);
  }

  // ==========================================
  // 1. ATAQUE BÁSICO: RAJADA ARCANA
  // ==========================================
  public fireArcaneBlast(aimPitch: number = 0): void {
    this.currentHand = this.currentHand === 'right' ? 'left' : 'right';
    const hand = this.currentHand;
    const handNode = hand === 'right' ? this.stickman.rightHand : this.stickman.leftHand;

    const handPos = new THREE.Vector3();
    handNode.getWorldPosition(handPos);

    const aim = this.getAimDestination();
    const dir = aim.pos.clone().sub(handPos).normalize();

    if (this.onArcaneCast) {
      this.onArcaneCast(hand, aimPitch);
    }

    const group = new THREE.Group();
    // Inner white-violet core line
    const coreGeo = new THREE.CylinderGeometry(0.065, 0.065, 0.8, 10);
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xf5d0fe });
    const core = new THREE.Mesh(coreGeo, coreMat);
    core.rotation.x = Math.PI / 2;
    group.add(core);

    // Deep glowing violet plasma capsule
    const glowGeo = new THREE.CylinderGeometry(0.24, 0.24, 1.05, 12);
    const glowMat = new THREE.MeshBasicMaterial({
      color: 0x9333ea,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const glow = new THREE.Mesh(glowGeo, glowMat);
    glow.rotation.x = Math.PI / 2;
    group.add(glow);

    // Trailing dark energy ring
    const ringGeo = new THREE.TorusGeometry(0.28, 0.04, 6, 16);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x3b0764,
      transparent: true,
      opacity: 0.9,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.y = Math.PI / 4;
    group.add(ring);

    const light = new THREE.PointLight(0xa855f7, 3.2, 5.5);
    group.add(light);

    group.position.copy(handPos);
    group.lookAt(handPos.clone().add(dir));
    this.scene.add(group);

    this.arcaneBolts.push({
      mesh: group,
      pos: handPos,
      vel: dir.multiplyScalar(44),
      startPos: handPos.clone(),
      maxRange: 45,
      target: aim.target,
      homingStrength: aim.target ? 8.5 : 0,
      isDead: false,
    });

    audioSystem.playArcaneBlast();
    this.onShake(0.02);

    // Hand casting spark burst
    for (let i = 0; i < 8; i++) {
      this.smokeParticles.push({
        pos: handPos.clone(),
        vel: new THREE.Vector3((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2),
        age: 0,
        maxAge: 0.35,
        size: 0.18,
        colorHex: 0xc084fc,
      });
    }
  }

  // ==========================================
  // 2. HABILIDADE: DRENAGEM SOMBRIA (3 SEGUNDOS)
  // ==========================================
  public triggerDarkDrain(playerPos: THREE.Vector3, dummies: TargetDummy[]): boolean {
    if (this.isDarkDrainActive) return false;

    // Scan for all living enemies within 14m radius
    const drainRadius = 14.0;
    const inRangeDummies: TargetDummy[] = [];
    for (const d of dummies) {
      if (d.isDead) continue;
      if (d.getCenter().distanceTo(playerPos) <= drainRadius) {
        inRangeDummies.push(d);
      }
    }

    if (inRangeDummies.length === 0) {
      // Small feedback chime that no targets in range
      audioSystem.playUiClick();
      return false;
    }

    this.isDarkDrainActive = true;
    this.darkDrainTimer = 0;
    this.darkDrainTickTimer = 0;
    this.drainChestOrb.visible = true;
    this.drainChestLight.intensity = 3.5;

    // Clear any previous tendrils
    this.clearDrainTendrils();

    // Create organic tendril and siphoning particles for each target
    for (const d of inRangeDummies) {
      const lineGeo = new THREE.BufferGeometry().setFromPoints(new Array(12).fill(new THREE.Vector3()));
      const lineMat = new THREE.LineBasicMaterial({
        color: 0xc084fc,
        linewidth: 3,
        transparent: true,
        opacity: 0.85,
      });
      const line = new THREE.Line(lineGeo, lineMat);
      this.scene.add(line);

      const glowGeo = new THREE.CylinderGeometry(0.14, 0.14, 1, 8, 1, true);
      const glowMat = new THREE.MeshBasicMaterial({
        color: 0x581c87,
        transparent: true,
        opacity: 0.7,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const glow = new THREE.Mesh(glowGeo, glowMat);
      this.scene.add(glow);

      const particles: { progress: number; speed: number; mesh: THREE.Mesh }[] = [];
      for (let p = 0; p < 4; p++) {
        const pGeo = new THREE.SphereGeometry(0.12, 8, 8);
        const pMat = new THREE.MeshBasicMaterial({ color: 0xf3e8ff, blending: THREE.AdditiveBlending });
        const pMesh = new THREE.Mesh(pGeo, pMat);
        this.scene.add(pMesh);
        particles.push({
          progress: p * 0.25,
          speed: 1.2 + Math.random() * 0.4,
          mesh: pMesh,
        });
      }

      this.activeDrainTendrils.set(d.id, {
        target: d,
        line,
        glow,
        particles,
      });
    }

    audioSystem.playDarkDrainPulse();
    this.onShake(0.06);
    return true;
  }

  private clearDrainTendrils(): void {
    for (const tendril of this.activeDrainTendrils.values()) {
      this.scene.remove(tendril.line);
      this.scene.remove(tendril.glow);
      for (const p of tendril.particles) {
        this.scene.remove(p.mesh);
      }
    }
    this.activeDrainTendrils.clear();
  }

  // ==========================================
  // 3. HABILIDADE: PASSO DAS SOMBRAS (TELEPORTE)
  // ==========================================
  public triggerShadowStep(
    currentPos: THREE.Vector3,
    inputDir: THREE.Vector3,
    structureBoxes: THREE.Box3[],
    onTeleport: (dest: THREE.Vector3) => void
  ): boolean {
    const teleportDistance = 11.5;
    const playerRadius = 0.55;

    // Determine normalized direction: if stationary, teleport forward along facing direction
    const dir = inputDir.lengthSq() > 0.05 ? inputDir.clone().normalize() : new THREE.Vector3(0, 0, -1);
    dir.y = 0;

    // Check step by step along path to respect collisions and avoid walls
    let validDist = teleportDistance;
    const stepSize = 0.4;
    const steps = Math.ceil(teleportDistance / stepSize);

    for (let s = 1; s <= steps; s++) {
      const checkDist = Math.min(teleportDistance, s * stepSize);
      const testPos = currentPos.clone().addScaledVector(dir, checkDist);

      for (const box of structureBoxes) {
        const expanded = box.clone();
        expanded.min.subScalar(playerRadius);
        expanded.max.addScalar(playerRadius);
        // Only block if player Y height intersects box
        if (testPos.y >= expanded.min.y && testPos.y <= expanded.max.y) {
          if (expanded.containsPoint(testPos)) {
            // Found collision: stop slightly before collision point
            validDist = Math.max(0, (s - 1) * stepSize - 0.2);
            break;
          }
        }
      }
      if (validDist < teleportDistance) break;
    }

    const destPos = currentPos.clone().addScaledVector(dir, validDist);

    // 1. Departure Effect: Agatha dissolves into dark smoke & violet particles
    for (let i = 0; i < 35; i++) {
      this.smokeParticles.push({
        pos: currentPos.clone().add(new THREE.Vector3(
          (Math.random() - 0.5) * 0.8,
          Math.random() * 1.8,
          (Math.random() - 0.5) * 0.8
        )),
        vel: new THREE.Vector3((Math.random() - 0.5) * 4, Math.random() * 3 + 1, (Math.random() - 0.5) * 4),
        age: 0,
        maxAge: 0.55,
        size: 0.28,
        colorHex: i % 2 === 0 ? 0x1f0638 : 0xa855f7,
      });
    }

    // 2. Perform Teleport
    onTeleport(destPos);

    // 3. Arrival Effect: Glowing Runic Circle on ground + shockwave & burst
    const decalGeo = new THREE.PlaneGeometry(3.2, 3.2);
    const decalMat = new THREE.MeshBasicMaterial({
      map: this.runicTexture,
      transparent: true,
      opacity: 0.95,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const runicMesh = new THREE.Mesh(decalGeo, decalMat);
    runicMesh.rotation.x = -Math.PI / 2;
    runicMesh.position.set(destPos.x, 0.03, destPos.z);
    this.scene.add(runicMesh);

    // Expanding dark energy ring
    const ringGeo = new THREE.RingGeometry(0.3, 1.2, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x9333ea,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(destPos.x, 0.05, destPos.z);
    this.scene.add(ringMesh);

    const light = new THREE.PointLight(0xc084fc, 4.5, 8);
    light.position.set(destPos.x, 1.2, destPos.z);
    this.scene.add(light);

    this.runicDecals.push({
      mesh: runicMesh,
      ring: ringMesh,
      light,
      age: 0,
      maxAge: 0.85,
    });

    // Arrival smoke burst
    for (let i = 0; i < 28; i++) {
      this.smokeParticles.push({
        pos: destPos.clone().add(new THREE.Vector3(
          (Math.random() - 0.5) * 0.9,
          Math.random() * 1.5,
          (Math.random() - 0.5) * 0.9
        )),
        vel: new THREE.Vector3((Math.random() - 0.5) * 3, Math.random() * 2.5, (Math.random() - 0.5) * 3),
        age: 0,
        maxAge: 0.45,
        size: 0.22,
        colorHex: 0x9333ea,
      });
    }

    audioSystem.playShadowStep();
    this.onShake(0.08);
    return true;
  }

  // ==========================================
  // 5. HABILIDADE: ESTRANGULAMENTO ARCANO (3 SEGUNDOS)
  // ==========================================
  public triggerArcaneChoke(
    playerPos: THREE.Vector3,
    dummies: TargetDummy[]
  ): boolean {
    if (this.chokeState.active) return false;

    // Find closest target within 20m from aim destination or player
    const aim = this.getAimDestination();
    let target = aim.target;

    if (!target || target.isDead) {
      let minDist = 20.0;
      for (const d of dummies) {
        if (d.isDead) continue;
        const dist = d.getCenter().distanceTo(playerPos);
        if (dist <= minDist) {
          minDist = dist;
          target = d;
        }
      }
    }

    if (!target || target.isDead || target.getCenter().distanceTo(playerPos) > 22.0) {
      audioSystem.playUiClick();
      return false;
    }

    this.chokeState.active = true;
    this.chokeState.target = target;
    this.chokeState.timer = 0;
    this.chokeState.tickTimer = 0;
    this.chokeElevationOffset = 0;

    target.isChoked = true;

    if (this.chokeState.leftCord) this.chokeState.leftCord.visible = true;
    if (this.chokeState.rightCord) this.chokeState.rightCord.visible = true;
    if (this.chokeState.neckCoil) this.chokeState.neckCoil.visible = true;
    if (this.chokeState.chokeLight) this.chokeState.chokeLight.intensity = 4.0;

    audioSystem.playArcaneChokeStart();
    this.onShake(0.07);
    return true;
  }

  public cancelArcaneChoke(): void {
    if (!this.chokeState.active) return;
    if (this.chokeState.target) {
      this.chokeState.target.isChoked = false;
    }
    this.chokeState.active = false;
    this.chokeState.target = null;
    this.chokeElevationOffset = 0;

    if (this.chokeState.leftCord) this.chokeState.leftCord.visible = false;
    if (this.chokeState.rightCord) this.chokeState.rightCord.visible = false;
    if (this.chokeState.neckCoil) this.chokeState.neckCoil.visible = false;
    if (this.chokeState.chokeLight) this.chokeState.chokeLight.intensity = 0;
  }

  // ==========================================
  // FRAME UPDATE LOOP
  // ==========================================
  public update(
    dt: number,
    playerPos: THREE.Vector3,
    dummies: TargetDummy[]
  ): void {
    const time = performance.now() * 0.001;

    // 1. Update Arcane Bolts
    for (let i = this.arcaneBolts.length - 1; i >= 0; i--) {
      const b = this.arcaneBolts[i];
      if (b.target && !b.target.isDead && b.homingStrength > 0) {
        const dest = b.target.getCenter();
        const dir = dest.clone().sub(b.pos).normalize();
        b.vel.lerp(dir.multiplyScalar(44), dt * b.homingStrength);
      }

      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);
      b.mesh.lookAt(b.pos.clone().add(b.vel));

      // Trailing dark magic smoke
      if (Math.random() < 0.6) {
        this.smokeParticles.push({
          pos: b.pos.clone(),
          vel: new THREE.Vector3((Math.random() - 0.5) * 0.8, (Math.random() - 0.5) * 0.8, (Math.random() - 0.5) * 0.8),
          age: 0,
          maxAge: 0.3,
          size: 0.16,
          colorHex: 0xa855f7,
        });
      }

      // Check hit against target dummies
      let hit = false;
      for (const d of dummies) {
        if (d.isDead) continue;
        if (b.pos.distanceTo(d.getCenter()) <= d.radius + 0.35) {
          hit = true;
          this.onDamageDealt(d, 9, b.pos.clone(), b.vel.clone().normalize().multiplyScalar(4));
          audioSystem.playImpact();
          this.onShake(0.025);

          // Impact particle flash
          for (let p = 0; p < 14; p++) {
            this.smokeParticles.push({
              pos: b.pos.clone(),
              vel: new THREE.Vector3((Math.random() - 0.5) * 5, Math.random() * 4, (Math.random() - 0.5) * 5),
              age: 0,
              maxAge: 0.4,
              size: 0.22,
              colorHex: p % 2 === 0 ? 0xc084fc : 0x3b0764,
            });
          }
          break;
        }
      }

      if (hit || b.pos.distanceTo(b.startPos) >= b.maxRange) {
        this.scene.remove(b.mesh);
        this.arcaneBolts.splice(i, 1);
      }
    }

    // 2. Update Drenagem Sombria (Dark Drain)
    if (this.isDarkDrainActive) {
      this.darkDrainTimer += dt;
      this.darkDrainTickTimer += dt;

      // Update Chest Vortex Orb
      const chestPos = new THREE.Vector3();
      this.stickman.upperTorso.getWorldPosition(chestPos);
      this.drainChestOrb.position.copy(chestPos).add(new THREE.Vector3(0, 0.1, -0.15));
      const orbPulse = 0.35 + Math.sin(time * 16) * 0.08;
      this.drainChestOrb.scale.set(orbPulse, orbPulse, orbPulse);
      this.drainChestLight.position.copy(this.drainChestOrb.position);

      // Check each active tendril
      for (const [id, tendril] of this.activeDrainTendrils.entries()) {
        if (tendril.target.isDead || tendril.target.getCenter().distanceTo(playerPos) > 16.0) {
          this.scene.remove(tendril.line);
          this.scene.remove(tendril.glow);
          for (const p of tendril.particles) this.scene.remove(p.mesh);
          this.activeDrainTendrils.delete(id);
          continue;
        }

        const tCenter = tendril.target.getCenter();
        const start = tCenter.clone();
        const end = this.drainChestOrb.position.clone();

        // Animated organic wave line points
        const points: THREE.Vector3[] = [];
        const segCount = 12;
        for (let s = 0; s <= segCount; s++) {
          const frac = s / segCount;
          const pt = new THREE.Vector3().lerpVectors(start, end, frac);
          // Sine wave oscillation
          const wave = Math.sin(time * 12 + frac * Math.PI * 4) * 0.25 * (1 - Math.abs(frac - 0.5) * 2);
          pt.x += wave * 0.5;
          pt.y += wave;
          points.push(pt);
        }
        (tendril.line.geometry as THREE.BufferGeometry).setFromPoints(points);

        // Position glow cylinder in center
        const mid = start.clone().add(end).multiplyScalar(0.5);
        tendril.glow.position.copy(mid);
        const dist = start.distanceTo(end);
        tendril.glow.scale.set(1, dist, 1);
        tendril.glow.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), end.clone().sub(start).normalize());

        // Update siphoning particles moving along the beam toward Agatha
        for (const p of tendril.particles) {
          p.progress = (p.progress + dt * p.speed) % 1.0;
          const posOnBeam = new THREE.Vector3().lerpVectors(start, end, p.progress);
          const pWave = Math.sin(time * 10 + p.progress * 8) * 0.18;
          posOnBeam.y += pWave;
          p.mesh.position.copy(posOnBeam);
          const pScale = 0.18 * (1 - p.progress * 0.4);
          p.mesh.scale.set(pScale, pScale, pScale);
        }
      }

      // Continuous tick damage: 4 damage every 0.25s
      if (this.darkDrainTickTimer >= 0.25) {
        this.darkDrainTickTimer = 0;
        audioSystem.playDarkDrainPulse();
        this.onShake(0.035);

        for (const tendril of this.activeDrainTendrils.values()) {
          this.onDamageDealt(tendril.target, 4, tendril.target.getCenter());
        }
      }

      // Check completion at 3.0 seconds
      if (this.darkDrainTimer >= this.darkDrainDuration || this.activeDrainTendrils.size === 0) {
        this.isDarkDrainActive = false;
        this.drainChestOrb.visible = false;
        this.drainChestLight.intensity = 0;
        this.clearDrainTendrils();

        // Dissipation magic burst
        for (let i = 0; i < 20; i++) {
          this.smokeParticles.push({
            pos: chestPos.clone(),
            vel: new THREE.Vector3((Math.random() - 0.5) * 3, Math.random() * 2, (Math.random() - 0.5) * 3),
            age: 0,
            maxAge: 0.45,
            size: 0.2,
            colorHex: 0xc084fc,
          });
        }
      }
    }

    // 3. Update Estrangulamento Arcano (Arcane Choke)
    if (this.chokeState.active) {
      this.chokeState.timer += dt;
      this.chokeState.tickTimer += dt;

      // Float smoothly upwards by 1.2m during choke
      this.chokeElevationOffset = THREE.MathUtils.damp(this.chokeElevationOffset, 1.2, 5.0, dt);

      const target = this.chokeState.target;
      if (!target || target.isDead || target.getCenter().distanceTo(playerPos) > 26.0) {
        this.cancelArcaneChoke();
      } else {
        const throatPos = target.getThroatPosition();

        const handL = new THREE.Vector3();
        const handR = new THREE.Vector3();
        this.stickman.leftHand.getWorldPosition(handL);
        this.stickman.rightHand.getWorldPosition(handR);

        // Update Left Cord
        const pointsL = [handL, throatPos];
        (this.chokeState.leftCord!.geometry as THREE.BufferGeometry).setFromPoints(pointsL);

        // Update Right Cord
        const pointsR = [handR, throatPos];
        (this.chokeState.rightCord!.geometry as THREE.BufferGeometry).setFromPoints(pointsR);

        // Neck Coil constriction ring
        this.chokeState.neckCoil!.position.copy(throatPos);
        const coilScale = 0.95 + Math.sin(time * 24) * 0.08;
        this.chokeState.neckCoil!.scale.set(coilScale, coilScale, coilScale);

        this.chokeState.chokeLight!.position.copy(throatPos);

        // Periodic choke tick damage: 5 damage every 0.30s
        if (this.chokeState.tickTimer >= 0.30) {
          this.chokeState.tickTimer = 0;
          this.onDamageDealt(target, 5, throatPos);
          audioSystem.playArcaneChokeTick();
          this.onShake(0.045);

          // Throat constriction sparks
          for (let p = 0; p < 6; p++) {
            this.smokeParticles.push({
              pos: throatPos.clone(),
              vel: new THREE.Vector3((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2),
              age: 0,
              maxAge: 0.25,
              size: 0.15,
              colorHex: 0xf3e8ff,
            });
          }
        }

        // Completion at exactly 3.0 seconds
        if (this.chokeState.timer >= this.chokeState.maxDuration) {
          this.cancelArcaneChoke();
        }
      }
    } else {
      // Lower elevation smoothly back down
      if (this.chokeElevationOffset > 0.01) {
        this.chokeElevationOffset = THREE.MathUtils.damp(this.chokeElevationOffset, 0, 7.0, dt);
      } else {
        this.chokeElevationOffset = 0;
      }
    }

    // 4. Update Arcane Flight Mystical Embers & Aura
    if (this.isArcaneFlightActive) {
      this.flightMistTimer += dt;
      if (this.flightMistTimer > 0.05) {
        this.flightMistTimer = 0;

        // Ascending purple smoke ribbons from feet and lower body
        const footL = new THREE.Vector3();
        const footR = new THREE.Vector3();
        this.stickman.leftFoot.getWorldPosition(footL);
        this.stickman.rightFoot.getWorldPosition(footR);

        this.smokeParticles.push({
          pos: footL.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.2, -0.1, (Math.random() - 0.5) * 0.2)),
          vel: new THREE.Vector3((Math.random() - 0.5) * 0.4, Math.random() * 0.8 + 0.3, (Math.random() - 0.5) * 0.4),
          age: 0,
          maxAge: 0.45,
          size: 0.22,
          colorHex: 0x9333ea,
        });

        this.smokeParticles.push({
          pos: footR.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.2, -0.1, (Math.random() - 0.5) * 0.2)),
          vel: new THREE.Vector3((Math.random() - 0.5) * 0.4, Math.random() * 0.8 + 0.3, (Math.random() - 0.5) * 0.4),
          age: 0,
          maxAge: 0.45,
          size: 0.22,
          colorHex: 0x581c87,
        });
      }

      // Floating ring aura beneath legs
      this.flightRingMesh.visible = true;
      this.flightRingMesh.position.set(playerPos.x, playerPos.y + 0.15, playerPos.z);
      this.flightRingMesh.rotation.z = time * 1.5;
    } else {
      this.flightRingMesh.visible = false;
    }

    // 5. Update Runic Arrival Decals
    for (let i = this.runicDecals.length - 1; i >= 0; i--) {
      const d = this.runicDecals[i];
      d.age += dt;
      const progress = d.age / d.maxAge;

      if (progress >= 1.0) {
        this.scene.remove(d.mesh);
        this.scene.remove(d.ring);
        this.scene.remove(d.light);
        this.runicDecals.splice(i, 1);
      } else {
        const fade = 1 - progress;
        (d.mesh.material as THREE.MeshBasicMaterial).opacity = fade * 0.9;
        const ringScale = 1.0 + progress * 2.2;
        d.ring.scale.set(ringScale, ringScale, ringScale);
        (d.ring.material as THREE.MeshBasicMaterial).opacity = fade * 0.8;
        d.light.intensity = fade * 4.5;
      }
    }

    // 6. Update Smoke Particles (Instanced Mesh)
    for (let i = this.smokeParticles.length - 1; i >= 0; i--) {
      const p = this.smokeParticles[i];
      p.age += dt;
      if (p.age >= p.maxAge) {
        this.smokeParticles.splice(i, 1);
      } else {
        p.pos.addScaledVector(p.vel, dt);
      }
    }

    const sCount = Math.min(this.smokeParticles.length, 220);
    this.smokeInstancedMesh.count = sCount;
    for (let i = 0; i < sCount; i++) {
      const p = this.smokeParticles[i];
      const scale = (1 - p.age / p.maxAge) * p.size;
      this.dummyMatrix.makeTranslation(p.pos.x, p.pos.y, p.pos.z);
      this.dummyMatrix.scale(new THREE.Vector3(scale, scale, scale));
      this.smokeInstancedMesh.setMatrixAt(i, this.dummyMatrix);
    }
    if (sCount > 0) {
      this.smokeInstancedMesh.instanceMatrix.needsUpdate = true;
    }
  }

  public dispose(): void {
    for (const b of this.arcaneBolts) this.scene.remove(b.mesh);
    this.clearDrainTendrils();
    this.cancelArcaneChoke();
    if (this.drainChestOrb) this.scene.remove(this.drainChestOrb);
    if (this.drainChestLight) this.scene.remove(this.drainChestLight);
    if (this.flightRingMesh) this.scene.remove(this.flightRingMesh);
    if (this.chokeState.leftCord) this.scene.remove(this.chokeState.leftCord);
    if (this.chokeState.rightCord) this.scene.remove(this.chokeState.rightCord);
    if (this.chokeState.neckCoil) this.scene.remove(this.chokeState.neckCoil);
    if (this.chokeState.chokeLight) this.scene.remove(this.chokeState.chokeLight);
    for (const d of this.runicDecals) {
      this.scene.remove(d.mesh);
      this.scene.remove(d.ring);
      this.scene.remove(d.light);
    }
    this.scene.remove(this.smokeInstancedMesh);
  }
}
