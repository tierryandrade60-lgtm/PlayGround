/**
 * Script Runtime Engine & Source Integration Pipeline
 * Manages custom user scripts, script creation, editing, deletion, compilation,
 * and live execution during Play Test mode.
 */

import { PROJECT_SCRIPTS, ProjectScriptInfo } from './RealProjectScripts';
import { liveConfigManager } from './LiveConfigManager';

export interface UserScriptDef extends ProjectScriptInfo {
  isUserCreated?: boolean;
  isDeleted?: boolean;
  compiledHook?: (gameScene: unknown, dt: number) => void;
}

const CUSTOM_SCRIPTS_KEY = 'stickman_custom_user_scripts';
const DELETED_SCRIPTS_KEY = 'stickman_deleted_default_scripts';

class ScriptRuntimeEngine {
  private customScripts: UserScriptDef[] = [];
  private deletedScriptIds: Set<string> = new Set();
  private activeHooks: Map<string, (gameScene: unknown, dt: number) => void> = new Map();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    try {
      const storedCustom = localStorage.getItem(CUSTOM_SCRIPTS_KEY);
      if (storedCustom) {
        this.customScripts = JSON.parse(storedCustom);
      }
      const storedDeleted = localStorage.getItem(DELETED_SCRIPTS_KEY);
      if (storedDeleted) {
        const arr = JSON.parse(storedDeleted);
        this.deletedScriptIds = new Set(arr);
      }
    } catch {
      this.customScripts = [];
      this.deletedScriptIds = new Set();
    }

    // Compile hooks for existing custom or edited scripts
    this.customScripts.forEach((script) => {
      const source = localStorage.getItem(`script_source_${script.id}`) || script.originalSource;
      this.compileAndRegisterHook(script.id, source);
    });
  }

  public getScripts(): ProjectScriptInfo[] {
    const defaults = PROJECT_SCRIPTS.filter((s) => !this.deletedScriptIds.has(s.id)).map((s) => {
      const savedSrc = localStorage.getItem(`script_source_${s.id}`);
      return savedSrc ? { ...s, originalSource: savedSrc } : s;
    });

    const customs = this.customScripts.filter((s) => !this.deletedScriptIds.has(s.id)).map((s) => {
      const savedSrc = localStorage.getItem(`script_source_${s.id}`);
      return savedSrc ? { ...s, originalSource: savedSrc } : s;
    });

    return [...customs, ...defaults];
  }

  public createScript(name: string, filePath: string, category: ProjectScriptInfo['category'], initialCode: string): UserScriptDef {
    const id = `custom_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newScript: UserScriptDef = {
      id,
      name,
      filePath,
      category,
      summary: 'Custom user script created in Build Mode.',
      originalSource: initialCode,
      fileExtension: filePath.endsWith('.tsx') ? 'tsx' : 'ts',
      isUserCreated: true,
    };

    this.customScripts.push(newScript);
    this.saveToStorage();
    this.applyScriptToGame(id, initialCode);
    return newScript;
  }

  public saveScriptCode(id: string, code: string): void {
    try {
      localStorage.setItem(`script_source_${id}`, code);
    } catch {
      // ignore
    }
    this.applyScriptToGame(id, code);
  }

  public deleteScript(id: string): void {
    this.deletedScriptIds.add(id);
    this.customScripts = this.customScripts.filter((s) => s.id !== id);
    this.activeHooks.delete(id);
    try {
      localStorage.setItem(DELETED_SCRIPTS_KEY, JSON.stringify(Array.from(this.deletedScriptIds)));
      localStorage.setItem(CUSTOM_SCRIPTS_KEY, JSON.stringify(this.customScripts));
      localStorage.removeItem(`script_source_${id}`);
    } catch {
      // ignore
    }
  }

  public applyScriptToGame(id: string, code: string): void {
    try {
      localStorage.setItem(`script_source_${id}`, code);
    } catch {
      // ignore
    }

    // 1. Parse live config tuning values
    const parsedOverrides: Record<string, number> = {};
    const keys = [
      'repulsorDamage',
      'missileCount',
      'missileDamage',
      'heavyMissileDamage',
      'arcaneBlastDamage',
      'darkDrainDps',
      'arcaneChokeDuration',
      'groundMaxSpeed',
      'flightMaxSpeed',
      'dashSpeed',
      'dashCooldown',
      'dashDuration',
      'jumpPadBounceMultiplier',
      'sunLightIntensity',
    ];

    keys.forEach((key) => {
      const regex = new RegExp(`\\b${key}\\s*[:=]\\s*([0-9]+(?:\\.[0-9]+)?)`, 'i');
      const match = code.match(regex);
      if (match && match[1]) {
        const val = parseFloat(match[1]);
        if (!isNaN(val)) {
          parsedOverrides[key] = val;
        }
      }
    });

    if (Object.keys(parsedOverrides).length > 0) {
      liveConfigManager.update(parsedOverrides);
    }

    // 2. Compile custom runtime hook if present
    this.compileAndRegisterHook(id, code);
  }

  private compileAndRegisterHook(id: string, code: string): void {
    try {
      // If code defines an onUpdate or custom behavior function, compile it securely
      if (code.includes('onUpdate') || code.includes('customBehavior') || code.includes('gameScene')) {
        // Safe evaluation wrapper
        const factory = new Function('gameScene', 'dt', 'liveConfigManager', `
          try {
            ${code}
            if (typeof onUpdate === 'function') {
              onUpdate(gameScene, dt);
            }
          } catch (e) {
            // Runtime script error ignored to prevent freezing
          }
        `);
        this.activeHooks.set(id, (scene, dt) => {
          factory(scene, dt, liveConfigManager);
        });
      } else {
        this.activeHooks.delete(id);
      }
    } catch {
      this.activeHooks.delete(id);
    }
  }

  public updateRunningScripts(gameScene: unknown, dt: number): void {
    this.activeHooks.forEach((hook) => {
      try {
        hook(gameScene, dt);
      } catch {
        // ignore
      }
    });
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(CUSTOM_SCRIPTS_KEY, JSON.stringify(this.customScripts));
    } catch {
      // ignore
    }
  }
}

export const scriptRuntimeEngine = new ScriptRuntimeEngine();
