import React, { useState } from 'react';
import { Palette, RotateCcw, X, Check } from 'lucide-react';
import { audioSystem } from '../game/AudioSystem';

interface ColorCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentColor: string | null;
  onApplyColor: (colorHex: string | null) => void;
}

const PRESET_COLORS = [
  { name: 'Azul Elétrico', hex: '#38bdf8' },
  { name: 'Vermelho Iron', hex: '#ff1133' },
  { name: 'Ambar Dourado', hex: '#f59e0b' },
  { name: 'Verde Esmeralda', hex: '#10b981' },
  { name: 'Roxo Místico', hex: '#a855f7' },
  { name: 'Rosa Magenta', hex: '#ec4899' },
  { name: 'Ciano Neon', hex: '#00f0ff' },
  { name: 'Branco Puro', hex: '#ffffff' },
];

export const ColorCustomizerModal: React.FC<ColorCustomizerModalProps> = ({
  isOpen,
  onClose,
  currentColor,
  onApplyColor,
}) => {
  const [selectedColor, setSelectedColor] = useState<string>(currentColor || '#ff1133');

  if (!isOpen) return null;

  const handleSelectPreset = (hex: string) => {
    audioSystem.playUiClick();
    setSelectedColor(hex);
    onApplyColor(hex);
  };

  const handleCustomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const hex = e.target.value;
    setSelectedColor(hex);
    onApplyColor(hex);
  };

  const handleReset = () => {
    audioSystem.playUiClick();
    onApplyColor(null);
    onClose();
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(10, 12, 16, 0.7)',
        backdropFilter: 'blur(6px)',
        WebkitBackdropFilter: 'blur(6px)',
        zIndex: 100,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '16px',
        touchAction: 'auto',
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '420px',
          backgroundColor: '#1b1d22',
          border: '1.5px solid rgba(255, 255, 255, 0.12)',
          borderRadius: '16px',
          boxShadow: '0 20px 40px rgba(0, 0, 0, 0.7), 0 0 15px rgba(245, 158, 11, 0.15)',
          color: '#e2e4e8',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          padding: '24px',
          gap: '20px',
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${selectedColor}, #1b1d22)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: `0 0 12px ${selectedColor}66`,
              }}
            >
              <Palette size={20} className="text-white drop-shadow" />
            </div>
            <div>
              <h2 style={{ fontSize: '15px', fontWeight: 800, margin: 0, letterSpacing: '0.04em' }}>
                RODA DE CORES DOS PODERES
              </h2>
              <p style={{ fontSize: '11px', color: '#9ca3af', margin: '2px 0 0 0' }}>
                Personalize a cor de todos os ataques e projéteis
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              audioSystem.playUiClick();
              onClose();
            }}
            style={{
              background: 'none',
              border: 'none',
              color: '#9ca3af',
              cursor: 'pointer',
              padding: '6px',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            className="hover:bg-white/10 hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Color Wheel / Picker section */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            backgroundColor: 'rgba(255, 255, 255, 0.03)',
            padding: '16px',
            borderRadius: '12px',
            border: '1px solid rgba(255, 255, 255, 0.06)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Seletor Personalizado (Roda / Hex)</span>
            <span style={{ fontSize: '12px', fontFamily: 'monospace', color: '#38bdf8', fontWeight: 700 }}>
              {selectedColor.toUpperCase()}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <input
              type="color"
              value={selectedColor}
              onChange={handleCustomChange}
              style={{
                width: '60px',
                height: '50px',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                background: 'transparent',
              }}
            />
            <div style={{ flex: 1, fontSize: '12px', color: '#9ca3af', lineHeight: 1.4 }}>
              Clique no seletor acima para abrir a roda de cores completa e escolher qualquer tonalidade para os poderes.
            </div>
          </div>
        </div>

        {/* Preset Swatches */}
        <div>
          <span style={{ fontSize: '12px', fontWeight: 600, color: '#9ca3af', display: 'block', marginBottom: '10px' }}>
            CORES PREDEFINIDAS
          </span>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px' }}>
            {PRESET_COLORS.map((preset) => {
              const isSelected = selectedColor.toLowerCase() === preset.hex.toLowerCase();
              return (
                <button
                  key={preset.hex}
                  onClick={() => handleSelectPreset(preset.hex)}
                  style={{
                    height: '42px',
                    borderRadius: '10px',
                    backgroundColor: preset.hex,
                    border: isSelected ? '2.5px solid #ffffff' : '1px solid rgba(255,255,255,0.2)',
                    boxShadow: isSelected ? `0 0 12px ${preset.hex}` : 'none',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'transform 0.1s ease',
                  }}
                  className="active:scale-95 hover:scale-105"
                  title={preset.name}
                >
                  {isSelected && <Check size={18} style={{ filter: 'invert(1)', mixBlendMode: 'difference' }} />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '10px', marginTop: '4px' }}>
          <button
            onClick={handleReset}
            style={{
              flex: 1,
              height: '42px',
              borderRadius: '10px',
              backgroundColor: 'rgba(239, 68, 68, 0.15)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              color: '#f87171',
              fontSize: '12px',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
              cursor: 'pointer',
              transition: 'background 0.15s',
            }}
            className="hover:bg-red-500/25 active:scale-95"
          >
            <RotateCcw size={16} />
            <span>Restaurar Original</span>
          </button>

          <button
            onClick={() => {
              audioSystem.playUiClick();
              onClose();
            }}
            style={{
              flex: 1,
              height: '42px',
              borderRadius: '10px',
              backgroundColor: '#38bdf8',
              border: 'none',
              color: '#0f172a',
              fontSize: '12px',
              fontWeight: 800,
              cursor: 'pointer',
              transition: 'filter 0.15s',
            }}
            className="hover:brightness-110 active:scale-95"
          >
            Aplicar & Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
