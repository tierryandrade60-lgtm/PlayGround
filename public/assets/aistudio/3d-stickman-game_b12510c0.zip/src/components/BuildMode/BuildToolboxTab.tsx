import React from 'react';
import {
  Box,
  Circle,
  Cylinder,
  Layers,
  Lightbulb,
  Shield,
  Target,
  Zap,
  Plus,
} from 'lucide-react';
import { BuildModeManager } from '../../game/BuildModeManager';
import { BuildObjectType } from '../../game/BuildTypes';
import { audioSystem } from '../../game/AudioSystem';

interface BuildToolboxTabProps {
  buildManager: BuildModeManager;
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
}

interface ToolboxItem {
  type: BuildObjectType;
  name: string;
  category: string;
  icon: React.ReactNode;
  description: string;
}

const TOOLBOX_ITEMS: ToolboxItem[] = [
  {
    type: 'part',
    name: 'Block / Part',
    category: 'Basic Geometry',
    icon: <Box size={20} className="text-blue-400" />,
    description: 'Standard rectangular building block for structures, pillars, and covers.',
  },
  {
    type: 'wedge',
    name: 'Wedge / Ramp',
    category: 'Basic Geometry',
    icon: <Layers size={20} className="text-purple-400" />,
    description: 'Triangular incline ramp for smooth elevation changes and parkour jumps.',
  },
  {
    type: 'cylinder',
    name: 'Cylinder',
    category: 'Basic Geometry',
    icon: <Cylinder size={20} className="text-amber-400" />,
    description: 'Round column, pipe, or barrel for arena obstacles and architectural detail.',
  },
  {
    type: 'sphere',
    name: 'Sphere',
    category: 'Basic Geometry',
    icon: <Circle size={20} className="text-emerald-400" />,
    description: 'Smooth round sphere for spherical markers, domes, and orb obstacles.',
  },
  {
    type: 'plane',
    name: 'Platform / Floor',
    category: 'Platforms',
    icon: <Layers size={20} className="text-slate-400" />,
    description: 'Wide flat platform tile for floating arenas, walkways, and stages.',
  },
  {
    type: 'jumppad',
    name: 'Interactive Jump Pad',
    category: 'Mechanics',
    icon: <Zap size={20} className="text-cyan-400" />,
    description: 'High-tech launch pad that propels the stickman skyward when stepped on!',
  },
  {
    type: 'barrier',
    name: 'Neon Forcefield Barrier',
    category: 'Barriers',
    icon: <Shield size={20} className="text-pink-400" />,
    description: 'Translucent glowing energy wall with solid collision and emissive pulse.',
  },
  {
    type: 'dummy',
    name: 'Target Dummy',
    category: 'Combat Actors',
    icon: <Target size={20} className="text-red-400" />,
    description: 'Training dummy with health bar, recoil physics, and hit confirm reactions.',
  },
  {
    type: 'light',
    name: 'Point Light',
    category: 'Lighting',
    icon: <Lightbulb size={20} className="text-yellow-400" />,
    description: 'Omnidirectional point light source with customizable radius and glow.',
  },
];

export const BuildToolboxTab: React.FC<BuildToolboxTabProps> = ({
  buildManager,
  onShowToast,
}) => {
  const handleInsert = (item: ToolboxItem) => {
    audioSystem.playUiClick();
    const id = buildManager.addPart(item.type);
    onShowToast(`Created ${item.name}!`, 'success');
  };

  return (
    <div style={{ height: '100%', overflowY: 'auto', paddingRight: '4px' }}>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
          gap: '8px',
        }}
      >
        {TOOLBOX_ITEMS.map((item) => (
          <div
            key={item.type}
            onClick={() => handleInsert(item)}
            style={{
              padding: '10px 12px',
              borderRadius: '10px',
              backgroundColor: 'rgba(255, 255, 255, 0.04)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              cursor: 'pointer',
              transition: 'background-color 0.15s ease, border-color 0.15s ease, transform 0.1s ease',
            }}
            className="hover:bg-slate-800/80 hover:border-cyan-500/50 active:scale-98"
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  {item.icon}
                  <span style={{ fontSize: '12px', fontWeight: 800, color: '#f1f5f9' }}>
                    {item.name}
                  </span>
                </div>
                <div
                  style={{
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%',
                    backgroundColor: 'rgba(0, 162, 255, 0.2)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#00a2ff',
                  }}
                >
                  <Plus size={12} />
                </div>
              </div>
              <p style={{ fontSize: '11px', color: '#94a3b8', lineHeight: 1.4, margin: 0 }}>
                {item.description}
              </p>
            </div>

            <div style={{ marginTop: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span
                style={{
                  fontSize: '9px',
                  fontWeight: 700,
                  color: '#64748b',
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                }}
              >
                {item.category}
              </span>
              <span style={{ fontSize: '10px', fontWeight: 700, color: '#38bdf8' }}>
                Tap to Insert
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
