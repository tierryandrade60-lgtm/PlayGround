import React from 'react';
import {
  Palette,
  Shield,
  Sun,
  Zap,
  Target,
  Copy,
  Trash2,
  Lock,
  Plus,
  Minus,
} from 'lucide-react';
import { BuildModeManager } from '../../game/BuildModeManager';
import { MaterialPresetType } from '../../game/BuildTypes';
import { audioSystem } from '../../game/AudioSystem';

interface BuildPropertiesTabProps {
  buildManager: BuildModeManager;
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
}

const COLOR_SWATCHES = [
  { name: 'Classic Blue', hex: '#3b82f6' },
  { name: 'Crimson Red', hex: '#ef4444' },
  { name: 'Emerald Green', hex: '#10b981' },
  { name: 'Amber Gold', hex: '#f59e0b' },
  { name: 'Purple Void', hex: '#8b5cf6' },
  { name: 'Neon Pink', hex: '#ec4899' },
  { name: 'Neon Cyan', hex: '#00f0ff' },
  { name: 'Slate Gray', hex: '#64748b' },
  { name: 'Porcelain White', hex: '#f8fafc' },
  { name: 'Obsidian Black', hex: '#1e293b' },
];

const MATERIAL_PRESETS: { type: MaterialPresetType; label: string }[] = [
  { type: 'plastic', label: 'Plastic' },
  { type: 'smooth', label: 'Smooth' },
  { type: 'metal', label: 'Metal' },
  { type: 'glass', label: 'Glass' },
  { type: 'neon', label: 'Neon Glow' },
  { type: 'wood', label: 'Wood' },
];

export const BuildPropertiesTab: React.FC<BuildPropertiesTabProps> = ({
  buildManager,
  onShowToast,
}) => {
  const selected = buildManager.getSelectedData();

  if (!selected) {
    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100%',
          color: '#64748b',
          textAlign: 'center',
          padding: '20px',
        }}
      >
        <div
          style={{
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            backgroundColor: 'rgba(255, 255, 255, 0.04)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: '10px',
          }}
        >
          <Target size={24} className="text-slate-500" />
        </div>
        <p style={{ fontSize: '13px', fontWeight: 600, color: '#94a3b8', marginBottom: '4px' }}>
          No Object Selected
        </p>
        <p style={{ fontSize: '11px', maxWidth: '240px', lineHeight: 1.4 }}>
          Tap any object in the 3D scene or select one from the Explorer tab to inspect and edit its properties.
        </p>
      </div>
    );
  }

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    buildManager.updateProperty(selected.id, 'name', e.target.value);
  };

  const handleColorChange = (hex: string) => {
    audioSystem.playUiClick();
    buildManager.updateProperty(selected.id, 'color', hex);
  };

  const handleMaterialChange = (mat: MaterialPresetType) => {
    audioSystem.playUiClick();
    buildManager.updateProperty(selected.id, 'materialType', mat);
  };

  const handleNumericInput = (
    category: 'position' | 'rotation' | 'scale',
    axisIndex: 0 | 1 | 2,
    rawVal: string
  ) => {
    const num = parseFloat(rawVal);
    if (isNaN(num)) return;
    const arr = [...selected[category]] as [number, number, number];
    arr[axisIndex] = num;
    buildManager.setExactTransform(
      selected.id,
      category === 'position' ? arr : undefined,
      category === 'rotation' ? arr : undefined,
      category === 'scale' ? arr : undefined
    );
  };

  return (
    <div style={{ height: '100%', overflowY: 'auto', paddingRight: '6px' }}>
      {/* Header Info */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '12px',
          paddingBottom: '10px',
          borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
          <input
            type="text"
            value={selected.name}
            onChange={handleNameChange}
            disabled={selected.isProtected}
            style={{
              fontSize: '13px',
              fontWeight: 800,
              color: '#ffffff',
              backgroundColor: selected.isProtected ? 'transparent' : 'rgba(0, 0, 0, 0.3)',
              border: selected.isProtected ? 'none' : '1px solid rgba(255, 255, 255, 0.15)',
              borderRadius: '6px',
              padding: '4px 8px',
              width: '100%',
              maxWidth: '220px',
            }}
          />
          <span
            style={{
              padding: '2px 8px',
              borderRadius: '6px',
              backgroundColor: 'rgba(0, 162, 255, 0.18)',
              color: '#38bdf8',
              fontSize: '10px',
              fontWeight: 800,
              textTransform: 'uppercase',
            }}
          >
            {selected.type}
          </span>
        </div>

        {selected.isProtected && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#94a3b8', fontSize: '10px', fontWeight: 700 }}>
            <Lock size={12} />
            <span>Protected</span>
          </div>
        )}
      </div>

      {/* Transform Section */}
      <div style={{ marginBottom: '16px' }}>
        <div style={{ fontSize: '11px', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', marginBottom: '8px' }}>
          Transform
        </div>

        {/* Position */}
        <div style={{ marginBottom: '8px' }}>
          <div style={{ fontSize: '10px', fontWeight: 700, color: '#cbd5e1', marginBottom: '4px' }}>Position (X, Y, Z)</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
            {(['x', 'y', 'z'] as const).map((axis, i) => (
              <div key={axis} style={{ display: 'flex', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.35)', borderRadius: '6px', padding: '2px 4px' }}>
                <span style={{ fontSize: '10px', fontWeight: 800, color: i === 0 ? '#ef4444' : i === 1 ? '#10b981' : '#3b82f6', marginRight: '4px' }}>
                  {axis.toUpperCase()}
                </span>
                <input
                  type="number"
                  step="0.5"
                  value={Number(selected.position[i].toFixed(2))}
                  onChange={(e) => handleNumericInput('position', i as 0 | 1 | 2, e.target.value)}
                  disabled={selected.isProtected}
                  style={{ width: '100%', backgroundColor: 'transparent', border: 'none', color: '#ffffff', fontSize: '11px', outline: 'none' }}
                />
                {!selected.isProtected && (
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <button
                      onClick={() => buildManager.nudgePosition(axis, 1)}
                      style={{ padding: '0 2px', border: 'none', background: 'transparent', color: '#94a3b8', cursor: 'pointer', lineHeight: 1 }}
                    >
                      <Plus size={9} />
                    </button>
                    <button
                      onClick={() => buildManager.nudgePosition(axis, -1)}
                      style={{ padding: '0 2px', border: 'none', background: 'transparent', color: '#94a3b8', cursor: 'pointer', lineHeight: 1 }}
                    >
                      <Minus size={9} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Rotation */}
        <div style={{ marginBottom: '8px' }}>
          <div style={{ fontSize: '10px', fontWeight: 700, color: '#cbd5e1', marginBottom: '4px' }}>Rotation (X, Y, Z degrees)</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
            {(['x', 'y', 'z'] as const).map((axis, i) => (
              <div key={axis} style={{ display: 'flex', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.35)', borderRadius: '6px', padding: '2px 4px' }}>
                <span style={{ fontSize: '10px', fontWeight: 800, color: i === 0 ? '#ef4444' : i === 1 ? '#10b981' : '#3b82f6', marginRight: '4px' }}>
                  {axis.toUpperCase()}
                </span>
                <input
                  type="number"
                  step="15"
                  value={Math.round(selected.rotation[i])}
                  onChange={(e) => handleNumericInput('rotation', i as 0 | 1 | 2, e.target.value)}
                  disabled={selected.isProtected}
                  style={{ width: '100%', backgroundColor: 'transparent', border: 'none', color: '#ffffff', fontSize: '11px', outline: 'none' }}
                />
                {!selected.isProtected && (
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <button
                      onClick={() => buildManager.nudgeRotation(axis, 1)}
                      style={{ padding: '0 2px', border: 'none', background: 'transparent', color: '#94a3b8', cursor: 'pointer', lineHeight: 1 }}
                    >
                      <Plus size={9} />
                    </button>
                    <button
                      onClick={() => buildManager.nudgeRotation(axis, -1)}
                      style={{ padding: '0 2px', border: 'none', background: 'transparent', color: '#94a3b8', cursor: 'pointer', lineHeight: 1 }}
                    >
                      <Minus size={9} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Scale */}
        <div style={{ marginBottom: '8px' }}>
          <div style={{ fontSize: '10px', fontWeight: 700, color: '#cbd5e1', marginBottom: '4px' }}>Scale / Size (X, Y, Z)</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
            {(['x', 'y', 'z'] as const).map((axis, i) => (
              <div key={axis} style={{ display: 'flex', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.35)', borderRadius: '6px', padding: '2px 4px' }}>
                <span style={{ fontSize: '10px', fontWeight: 800, color: i === 0 ? '#ef4444' : i === 1 ? '#10b981' : '#3b82f6', marginRight: '4px' }}>
                  {axis.toUpperCase()}
                </span>
                <input
                  type="number"
                  step="0.25"
                  value={Number(selected.scale[i].toFixed(2))}
                  onChange={(e) => handleNumericInput('scale', i as 0 | 1 | 2, e.target.value)}
                  disabled={selected.isProtected}
                  style={{ width: '100%', backgroundColor: 'transparent', border: 'none', color: '#ffffff', fontSize: '11px', outline: 'none' }}
                />
                {!selected.isProtected && (
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <button
                      onClick={() => buildManager.nudgeScale(1, false, axis)}
                      style={{ padding: '0 2px', border: 'none', background: 'transparent', color: '#94a3b8', cursor: 'pointer', lineHeight: 1 }}
                    >
                      <Plus size={9} />
                    </button>
                    <button
                      onClick={() => buildManager.nudgeScale(-1, false, axis)}
                      style={{ padding: '0 2px', border: 'none', background: 'transparent', color: '#94a3b8', cursor: 'pointer', lineHeight: 1 }}
                    >
                      <Minus size={9} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Appearance Section */}
      {selected.type !== 'dummy' && selected.type !== 'light' && (
        <div style={{ marginBottom: '16px' }}>
          <div style={{ fontSize: '11px', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', marginBottom: '8px' }}>
            Appearance & Material
          </div>

          {/* Color Swatches */}
          <div style={{ marginBottom: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
              <span style={{ fontSize: '10px', fontWeight: 700, color: '#cbd5e1' }}>Color Palette</span>
              <input
                type="color"
                value={selected.color}
                onChange={(e) => handleColorChange(e.target.value)}
                style={{ width: '24px', height: '20px', borderRadius: '4px', border: 'none', cursor: 'pointer', background: 'none' }}
              />
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
              {COLOR_SWATCHES.map((swatch) => (
                <button
                  key={swatch.hex}
                  onClick={() => handleColorChange(swatch.hex)}
                  style={{
                    width: '22px',
                    height: '22px',
                    borderRadius: '4px',
                    backgroundColor: swatch.hex,
                    border: selected.color.toLowerCase() === swatch.hex.toLowerCase() ? '2px solid #ffffff' : '1px solid rgba(255, 255, 255, 0.2)',
                    cursor: 'pointer',
                    boxShadow: selected.color.toLowerCase() === swatch.hex.toLowerCase() ? '0 0 8px rgba(255, 255, 255, 0.6)' : 'none',
                  }}
                  title={swatch.name}
                />
              ))}
            </div>
          </div>

          {/* Material Presets */}
          <div>
            <div style={{ fontSize: '10px', fontWeight: 700, color: '#cbd5e1', marginBottom: '6px' }}>Material Preset</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '4px' }}>
              {MATERIAL_PRESETS.map((mat) => (
                <button
                  key={mat.type}
                  onClick={() => handleMaterialChange(mat.type)}
                  style={{
                    padding: '5px 8px',
                    borderRadius: '6px',
                    backgroundColor: selected.materialType === mat.type ? '#00a2ff' : 'rgba(255, 255, 255, 0.05)',
                    color: selected.materialType === mat.type ? '#ffffff' : '#cbd5e1',
                    border: 'none',
                    fontSize: '11px',
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                >
                  {mat.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Physics & Collision Section */}
      <div style={{ marginBottom: '16px' }}>
        <div style={{ fontSize: '11px', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', marginBottom: '8px' }}>
          Physics & Lighting
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#e2e8f0', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={selected.canCollide}
              onChange={(e) => buildManager.updateProperty(selected.id, 'canCollide', e.target.checked)}
              disabled={selected.isProtected}
            />
            <span>CanCollide (Solid Physics Obstacle)</span>
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#e2e8f0', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={buildManager.showCollisionHelpers}
              onChange={(e) => buildManager.toggleCollisionVisibility(e.target.checked)}
            />
            <span style={{ color: '#f87171' }}>Visualize All Collisions</span>
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#e2e8f0', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={selected.castShadow}
              onChange={(e) => buildManager.updateProperty(selected.id, 'castShadow', e.target.checked)}
            />
            <span>Cast Shadow</span>
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#e2e8f0', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={selected.receiveShadow}
              onChange={(e) => buildManager.updateProperty(selected.id, 'receiveShadow', e.target.checked)}
            />
            <span>Receive Shadow</span>
          </label>
        </div>
      </div>

      {/* Custom Object Settings (Dummies, Lights, JumpPads) */}
      {selected.type === 'dummy' && (
        <div style={{ marginBottom: '16px', padding: '10px', backgroundColor: 'rgba(239, 68, 68, 0.1)', borderRadius: '8px', border: '1px solid rgba(239, 68, 68, 0.25)' }}>
          <div style={{ fontSize: '11px', fontWeight: 800, color: '#f87171', textTransform: 'uppercase', marginBottom: '6px' }}>
            Dummy Combat Attributes
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '12px', color: '#e2e8f0' }}>Max Health</span>
            <input
              type="number"
              value={selected.dummyHealth || 100}
              onChange={(e) => buildManager.updateProperty(selected.id, 'dummyHealth', Number(e.target.value))}
              style={{ width: '80px', padding: '4px', borderRadius: '4px', backgroundColor: '#0f172a', border: '1px solid #334155', color: '#ffffff', fontSize: '12px' }}
            />
          </div>
        </div>
      )}

      {selected.type === 'jumppad' && (
        <div style={{ marginBottom: '16px', padding: '10px', backgroundColor: 'rgba(0, 240, 255, 0.1)', borderRadius: '8px', border: '1px solid rgba(0, 240, 255, 0.25)' }}>
          <div style={{ fontSize: '11px', fontWeight: 800, color: '#00f0ff', textTransform: 'uppercase', marginBottom: '6px' }}>
            Jump Pad Settings
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '12px', color: '#e2e8f0' }}>Bounce Power ({selected.bouncePower || 20})</span>
            <input
              type="range"
              min="10"
              max="40"
              value={selected.bouncePower || 20}
              onChange={(e) => buildManager.updateProperty(selected.id, 'bouncePower', Number(e.target.value))}
              style={{ width: '120px' }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
