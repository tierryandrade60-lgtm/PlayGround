import React, { useState, useEffect, useCallback } from 'react';
import {
  FolderTree,
  PackagePlus,
  SlidersHorizontal,
  Code2,
  HardDriveDownload,
  PanelLeftClose,
  PanelRightClose,
} from 'lucide-react';
import { GameScene } from '../../game/GameScene';
import { TransformMode } from '../../game/BuildTypes';
import { BuildModeToolbar } from './BuildModeToolbar';
import { BuildExplorerTab } from './BuildExplorerTab';
import { BuildToolboxTab } from './BuildToolboxTab';
import { BuildPropertiesTab } from './BuildPropertiesTab';
import { BuildScriptsTab } from './BuildScriptsTab';
import { BuildSaveExportTab } from './BuildSaveExportTab';
import { BuildGizmoOverlay } from './BuildGizmoOverlay';
import { BuildToast, ToastMessage } from './BuildToast';
import { audioSystem } from '../../game/AudioSystem';

interface BuildModeContainerProps {
  gameScene: GameScene;
  onExitBuildMode: () => void;
}

type LeftTab = 'explorer' | 'toolbox';
type RightTab = 'properties' | 'scripts' | 'save';

export const BuildModeContainer: React.FC<BuildModeContainerProps> = ({
  gameScene,
  onExitBuildMode,
}) => {
  const buildManager = gameScene.buildModeManager;
  const [leftTab, setLeftTab] = useState<LeftTab>('explorer');
  const [rightTab, setRightTab] = useState<RightTab>('properties');
  const [isLeftOpen, setIsLeftOpen] = useState(true);
  const [isRightOpen, setIsRightOpen] = useState(true);

  const [transformMode, setTransformMode] = useState<TransformMode>('select');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [, setTick] = useState(0);

  const handleSetTransformMode = useCallback((mode: TransformMode) => {
    setTransformMode(mode);
    buildManager.setTransformMode(mode);
  }, [buildManager]);

  // Subscribe to BuildModeManager events for reactive updates
  useEffect(() => {
    const unsub = buildManager.subscribe(() => {
      setTick((t) => t + 1);
    });
    return unsub;
  }, [buildManager]);

  const showToast = useCallback((text: string, type: 'info' | 'success' | 'warn' = 'info') => {
    const id = `toast_${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2400);
  }, []);

  const handleSelectObject = (id: string) => {
    buildManager.selectObject(id);
    setRightTab('properties');
    setIsRightOpen(true);
    // On mobile screens, auto-close left panel when inspecting selected object
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      setIsLeftOpen(false);
    }
  };

  const handleToggleLeft = () => {
    const next = !isLeftOpen;
    setIsLeftOpen(next);
    if (next && typeof window !== 'undefined' && window.innerWidth < 768) {
      setIsRightOpen(false);
    }
  };

  const handleToggleRight = () => {
    const next = !isRightOpen;
    setIsRightOpen(next);
    if (next && typeof window !== 'undefined' && window.innerWidth < 768) {
      setIsLeftOpen(false);
    }
  };

  const selectedData = buildManager.getSelectedData();

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 65, touchAction: 'none' }}>
      {/* Top Floating Toolbar */}
      <div style={{ pointerEvents: 'auto' }}>
        <BuildModeToolbar
          buildManager={buildManager}
          transformMode={transformMode}
          onSetTransformMode={handleSetTransformMode}
          onToggleBuildMode={onExitBuildMode}
          onToggleLeftPanel={handleToggleLeft}
          onToggleRightPanel={handleToggleRight}
          isLeftOpen={isLeftOpen}
          isRightOpen={isRightOpen}
          onShowToast={showToast}
        />
      </div>

      {/* Touch-Friendly Transform Nudge Pad */}
      <div style={{ pointerEvents: 'auto' }}>
        <BuildGizmoOverlay buildManager={buildManager} transformMode={transformMode} />
      </div>

      {/* Left Side Panel (Explorer & Toolbox) - Strictly Top/Left positioning, clear bottom */}
      {isLeftOpen && (
        <div
          style={{
            position: 'fixed',
            top: '72px',
            bottom: '24px',
            left: '12px',
            width: 'min(300px, calc(100vw - 24px))',
            zIndex: 75,
            pointerEvents: 'auto',
            backgroundColor: 'rgba(12, 16, 24, 0.96)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: '14px',
            boxShadow: '0 10px 36px rgba(0, 0, 0, 0.85)',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}
        >
          {/* Header Tabs */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '8px 10px',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
            }}
          >
            <div style={{ display: 'flex', gap: '4px' }}>
              <button
                onClick={() => {
                  audioSystem.playUiClick();
                  setLeftTab('explorer');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '6px 10px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: leftTab === 'explorer' ? '#00a2ff' : 'transparent',
                  color: leftTab === 'explorer' ? '#ffffff' : '#94a3b8',
                  fontSize: '11px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                <FolderTree size={13} />
                <span>Explorer</span>
              </button>

              <button
                onClick={() => {
                  audioSystem.playUiClick();
                  setLeftTab('toolbox');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '6px 10px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: leftTab === 'toolbox' ? '#00a2ff' : 'transparent',
                  color: leftTab === 'toolbox' ? '#ffffff' : '#94a3b8',
                  fontSize: '11px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                <PackagePlus size={13} />
                <span>Toolbox</span>
              </button>
            </div>

            <button
              onClick={() => {
                audioSystem.playUiClick();
                setIsLeftOpen(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                color: '#94a3b8',
                cursor: 'pointer',
                padding: '4px',
              }}
              title="Close Panel"
            >
              <PanelLeftClose size={16} />
            </button>
          </div>

          {/* Body Content */}
          <div style={{ flex: 1, overflow: 'hidden', padding: '10px' }}>
            {leftTab === 'explorer' && (
              <BuildExplorerTab
                buildManager={buildManager}
                onSelectObject={handleSelectObject}
                onShowToast={showToast}
              />
            )}
            {leftTab === 'toolbox' && (
              <BuildToolboxTab buildManager={buildManager} onShowToast={showToast} />
            )}
          </div>
        </div>
      )}

      {/* Right Side Panel (Properties, Scripts, Save/Export) - Strictly Top/Right positioning, clear bottom */}
      {isRightOpen && (
        <div
          style={{
            position: 'fixed',
            top: '72px',
            bottom: '24px',
            right: '12px',
            width: 'min(320px, calc(100vw - 24px))',
            zIndex: 75,
            pointerEvents: 'auto',
            backgroundColor: 'rgba(12, 16, 24, 0.96)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: '14px',
            boxShadow: '0 10px 36px rgba(0, 0, 0, 0.85)',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}
        >
          {/* Header Tabs */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '8px 10px',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
            }}
          >
            <div style={{ display: 'flex', gap: '4px', overflowX: 'auto' }}>
              <button
                onClick={() => {
                  audioSystem.playUiClick();
                  setRightTab('properties');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '5px',
                  padding: '6px 8px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: rightTab === 'properties' ? '#00a2ff' : 'transparent',
                  color: rightTab === 'properties' ? '#ffffff' : '#94a3b8',
                  fontSize: '11px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                <SlidersHorizontal size={13} />
                <span>Inspector</span>
                {selectedData && (
                  <span style={{ width: '5px', height: '5px', borderRadius: '50%', backgroundColor: '#38bdf8' }} />
                )}
              </button>

              <button
                onClick={() => {
                  audioSystem.playUiClick();
                  setRightTab('scripts');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '5px',
                  padding: '6px 8px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: rightTab === 'scripts' ? '#00a2ff' : 'transparent',
                  color: rightTab === 'scripts' ? '#ffffff' : '#94a3b8',
                  fontSize: '11px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                <Code2 size={13} />
                <span>Scripts</span>
              </button>

              <button
                onClick={() => {
                  audioSystem.playUiClick();
                  setRightTab('save');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '5px',
                  padding: '6px 8px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: rightTab === 'save' ? '#00a2ff' : 'transparent',
                  color: rightTab === 'save' ? '#ffffff' : '#94a3b8',
                  fontSize: '11px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                <HardDriveDownload size={13} />
                <span>Save</span>
              </button>
            </div>

            <button
              onClick={() => {
                audioSystem.playUiClick();
                setIsRightOpen(false);
              }}
              style={{
                background: 'none',
                border: 'none',
                color: '#94a3b8',
                cursor: 'pointer',
                padding: '4px',
              }}
              title="Close Panel"
            >
              <PanelRightClose size={16} />
            </button>
          </div>

          {/* Body Content */}
          <div style={{ flex: 1, overflow: 'hidden', padding: '10px' }}>
            {rightTab === 'properties' && (
              <BuildPropertiesTab buildManager={buildManager} onShowToast={showToast} />
            )}
            {rightTab === 'scripts' && (
              <BuildScriptsTab onShowToast={showToast} />
            )}
            {rightTab === 'save' && (
              <BuildSaveExportTab buildManager={buildManager} onShowToast={showToast} />
            )}
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <BuildToast toasts={toasts} />
    </div>
  );
};
