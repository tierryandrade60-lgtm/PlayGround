import React, { useState } from 'react';
import {
  Save,
  Download,
  Upload,
  RotateCcw,
  Archive,
  Database,
  CheckCircle2,
  AlertOctagon,
  FileText,
} from 'lucide-react';
import { BuildModeManager } from '../../game/BuildModeManager';
import { PROJECT_SCRIPTS } from '../../game/RealProjectScripts';
import { audioSystem } from '../../game/AudioSystem';

interface BuildSaveExportTabProps {
  buildManager: BuildModeManager;
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
}

export const BuildSaveExportTab: React.FC<BuildSaveExportTabProps> = ({
  buildManager,
  onShowToast,
}) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [backupJson, setBackupJson] = useState<string | null>(null);

  const userCount = buildManager.getUserObjectsCount();
  const allObjects = buildManager.getObjectsList();

  const handleSave = () => {
    audioSystem.playUiClick();
    if (buildManager.saveToStorage()) {
      onShowToast('Scene saved to browser storage!', 'success');
    } else {
      onShowToast('Could not save scene to storage', 'warn');
    }
  };

  const handleLoad = () => {
    audioSystem.playUiClick();
    if (buildManager.loadFromStorage()) {
      onShowToast('Loaded last saved scene!', 'success');
    } else {
      onShowToast('No saved scene found in storage', 'info');
    }
  };

  const handleExportJson = () => {
    audioSystem.playUiClick();
    const jsonStr = buildManager.exportSceneJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `stickman_arena_build_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast('Exported scene as JSON file', 'success');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result;
      if (typeof content === 'string') {
        const res = buildManager.importSceneJson(content);
        if (res.success) {
          onShowToast('Scene imported successfully!', 'success');
        } else {
          onShowToast(res.message, 'warn');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset input
  };

  const handleExportAllScripts = () => {
    audioSystem.playUiClick();
    let bundle = `/**\n * 3D Stickman Game - Complete Project Source Bundle\n * Generated on ${new Date().toISOString()}\n */\n\n`;

    PROJECT_SCRIPTS.forEach((s) => {
      bundle += `\n/* ==========================================================================\n`;
      bundle += ` * File: ${s.filePath}\n`;
      bundle += ` * Category: ${s.category}\n`;
      bundle += ` * Purpose: ${s.summary}\n`;
      bundle += ` * ========================================================================== */\n\n`;
      bundle += s.originalSource;
      bundle += `\n\n`;
    });

    const blob = new Blob([bundle], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `stickman_project_scripts_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast('Exported complete project scripts bundle', 'success');
  };

  const handleCreateBackup = () => {
    audioSystem.playUiClick();
    const jsonStr = buildManager.exportSceneJson();
    setBackupJson(jsonStr);
    onShowToast('Local backup created in session memory', 'success');
  };

  const handleRestoreBackup = () => {
    audioSystem.playUiClick();
    if (!backupJson) return;
    const res = buildManager.importSceneJson(backupJson);
    if (res.success) {
      onShowToast('Restored scene from local session backup!', 'success');
    } else {
      onShowToast('Could not restore backup', 'warn');
    }
  };

  const confirmReset = () => {
    audioSystem.playUiClick();
    buildManager.resetAllUserConstructions();
    setShowResetConfirm(false);
    onShowToast('Arena scene reset to default layout', 'info');
  };

  return (
    <div style={{ height: '100%', overflowY: 'auto', paddingRight: '4px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '12px' }}>
        {/* Persistence Card */}
        <div
          style={{
            padding: '14px',
            borderRadius: '10px',
            backgroundColor: 'rgba(255, 255, 255, 0.03)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <Database size={18} className="text-emerald-400" />
              <span style={{ fontSize: '13px', fontWeight: 800, color: '#f1f5f9' }}>
                Browser Persistence
              </span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8', lineHeight: 1.4, marginBottom: '14px' }}>
              Save your user-created objects, transforms, and live configurations locally in your browser&apos;s storage.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={handleSave}
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                padding: '8px 12px',
                borderRadius: '8px',
                backgroundColor: '#10b981',
                color: '#ffffff',
                border: 'none',
                fontSize: '11px',
                fontWeight: 800,
                cursor: 'pointer',
              }}
            >
              <Save size={14} />
              <span>Save Scene</span>
            </button>

            <button
              onClick={handleLoad}
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                padding: '8px 12px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.08)',
                color: '#cbd5e1',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              <RotateCcw size={14} />
              <span>Load Last</span>
            </button>
          </div>
        </div>

        {/* JSON File Export & Import Card */}
        <div
          style={{
            padding: '14px',
            borderRadius: '10px',
            backgroundColor: 'rgba(255, 255, 255, 0.03)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <Archive size={18} className="text-cyan-400" />
              <span style={{ fontSize: '13px', fontWeight: 800, color: '#f1f5f9' }}>
                Scene JSON File
              </span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8', lineHeight: 1.4, marginBottom: '14px' }}>
              Export your arena construction as a downloadable JSON file or load a previously saved arena.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={handleExportJson}
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                padding: '8px 12px',
                borderRadius: '8px',
                backgroundColor: '#00a2ff',
                color: '#ffffff',
                border: 'none',
                fontSize: '11px',
                fontWeight: 800,
                cursor: 'pointer',
              }}
            >
              <Download size={14} />
              <span>Export JSON</span>
            </button>

            <label
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                padding: '8px 12px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.08)',
                color: '#cbd5e1',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              <Upload size={14} />
              <span>Import JSON</span>
              <input
                type="file"
                accept=".json,application/json"
                onChange={handleFileUpload}
                style={{ display: 'none' }}
              />
            </label>
          </div>
        </div>

        {/* Export Scripts & Session Backups */}
        <div
          style={{
            padding: '14px',
            borderRadius: '10px',
            backgroundColor: 'rgba(255, 255, 255, 0.03)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <FileText size={18} className="text-amber-400" />
              <span style={{ fontSize: '13px', fontWeight: 800, color: '#f1f5f9' }}>
                Script & Session Backups
              </span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8', lineHeight: 1.4, marginBottom: '14px' }}>
              Download all authentic project source files as a single text file or save an in-memory snapshot.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={handleExportAllScripts}
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                padding: '8px 10px',
                borderRadius: '8px',
                backgroundColor: 'rgba(245, 158, 11, 0.2)',
                color: '#fbbf24',
                border: '1px solid rgba(245, 158, 11, 0.4)',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              <Download size={14} />
              <span>Export All Code</span>
            </button>

            <button
              onClick={handleCreateBackup}
              style={{
                padding: '8px 12px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.08)',
                color: '#cbd5e1',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
              title="Create Session Backup"
            >
              Snapshot
            </button>

            {backupJson && (
              <button
                onClick={handleRestoreBackup}
                style={{
                  padding: '8px 12px',
                  borderRadius: '8px',
                  backgroundColor: 'rgba(0, 162, 255, 0.2)',
                  color: '#38bdf8',
                  border: '1px solid rgba(0, 162, 255, 0.4)',
                  fontSize: '11px',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
                title="Restore Session Snapshot"
              >
                Restore
              </button>
            )}
          </div>
        </div>

        {/* Scene Statistics & Reset */}
        <div
          style={{
            padding: '14px',
            borderRadius: '10px',
            backgroundColor: 'rgba(255, 255, 255, 0.03)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ fontSize: '13px', fontWeight: 800, color: '#f1f5f9' }}>Scene Stats</span>
              <span style={{ fontSize: '11px', color: '#38bdf8', fontWeight: 700 }}>
                {userCount} user parts
              </span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px', marginBottom: '12px' }}>
              <div style={{ padding: '6px 8px', borderRadius: '6px', backgroundColor: 'rgba(0, 0, 0, 0.3)', fontSize: '11px' }}>
                <span style={{ color: '#94a3b8' }}>Total Entities: </span>
                <strong style={{ color: '#ffffff' }}>{allObjects.length}</strong>
              </div>
              <div style={{ padding: '6px 8px', borderRadius: '6px', backgroundColor: 'rgba(0, 0, 0, 0.3)', fontSize: '11px' }}>
                <span style={{ color: '#94a3b8' }}>Solid Obstacles: </span>
                <strong style={{ color: '#ffffff' }}>{allObjects.filter((o) => o.canCollide).length}</strong>
              </div>
            </div>
          </div>

          <button
            onClick={() => setShowResetConfirm(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
              padding: '8px 12px',
              borderRadius: '8px',
              backgroundColor: 'rgba(239, 68, 68, 0.15)',
              color: '#f87171',
              border: '1px solid rgba(239, 68, 68, 0.35)',
              fontSize: '11px',
              fontWeight: 800,
              cursor: 'pointer',
            }}
          >
            <AlertOctagon size={14} />
            <span>Reset Scene Layout</span>
          </button>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.75)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '16px',
          }}
        >
          <div
            style={{
              backgroundColor: '#181e2b',
              border: '1.5px solid rgba(239, 68, 68, 0.6)',
              borderRadius: '14px',
              padding: '20px',
              maxWidth: '380px',
              width: '100%',
              boxShadow: '0 16px 40px rgba(0, 0, 0, 0.85)',
              color: '#ffffff',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
              <AlertOctagon className="text-red-400" size={22} />
              <h3 style={{ fontSize: '15px', fontWeight: 800, margin: 0 }}>Reset Scene Constructions?</h3>
            </div>
            <p style={{ fontSize: '13px', color: '#cbd5e1', lineHeight: 1.5, marginBottom: '20px' }}>
              This will remove all user-created parts, obstacles, jump pads, and reset tuning configurations to original default settings. Core arena structures and training dummies will be preserved.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button
                onClick={() => setShowResetConfirm(false)}
                style={{
                  padding: '8px 14px',
                  borderRadius: '8px',
                  backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  color: '#ffffff',
                  border: 'none',
                  fontSize: '12px',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                Cancel
              </button>
              <button
                onClick={confirmReset}
                style={{
                  padding: '8px 16px',
                  borderRadius: '8px',
                  backgroundColor: '#ef4444',
                  color: '#ffffff',
                  border: 'none',
                  fontSize: '12px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
