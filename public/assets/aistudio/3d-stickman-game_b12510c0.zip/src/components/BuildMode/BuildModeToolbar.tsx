import React, { useState } from 'react';
import {
  Play,
  Hammer,
  MousePointer,
  Move,
  RotateCw,
  Maximize2,
  Undo2,
  Redo2,
  Copy,
  Trash2,
  Target,
  Save,
  ChevronDown,
  ChevronUp,
  Grid,
  ShieldAlert,
  PanelLeftOpen,
  PanelRightOpen,
  FolderTree,
  SlidersHorizontal,
} from 'lucide-react';
import { TransformMode, GridSnapSetting, RotateSnapSetting } from '../../game/BuildTypes';
import { BuildModeManager } from '../../game/BuildModeManager';
import { audioSystem } from '../../game/AudioSystem';

interface BuildModeToolbarProps {
  buildManager: BuildModeManager;
  transformMode: TransformMode;
  onSetTransformMode: (mode: TransformMode) => void;
  onToggleBuildMode: () => void;
  onToggleLeftPanel: () => void;
  onToggleRightPanel: () => void;
  isLeftOpen: boolean;
  isRightOpen: boolean;
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
}

export const BuildModeToolbar: React.FC<BuildModeToolbarProps> = ({
  buildManager,
  transformMode,
  onSetTransformMode,
  onToggleBuildMode,
  onToggleLeftPanel,
  onToggleRightPanel,
  isLeftOpen,
  isRightOpen,
  onShowToast,
}) => {
  const [showSnapMenu, setShowSnapMenu] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const selected = buildManager.getSelectedData();
  const canUndo = buildManager.canUndo();
  const canRedo = buildManager.canRedo();

  const handleUndo = () => {
    audioSystem.playUiClick();
    if (buildManager.undo()) {
      onShowToast('Undo last action');
    }
  };

  const handleRedo = () => {
    audioSystem.playUiClick();
    if (buildManager.redo()) {
      onShowToast('Redo action');
    }
  };

  const handleDuplicate = () => {
    audioSystem.playUiClick();
    const id = buildManager.duplicateSelected();
    if (id) {
      onShowToast('Object duplicated!', 'success');
    }
  };

  const handleDelete = () => {
    if (!selected) return;
    if (selected.isProtected) {
      onShowToast('Protected game object cannot be deleted', 'warn');
      return;
    }
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    audioSystem.playUiClick();
    if (buildManager.deleteSelected()) {
      onShowToast('Object deleted', 'info');
    }
    setShowDeleteConfirm(false);
  };

  const handleFocus = () => {
    audioSystem.playUiClick();
    if (selected) {
      buildManager.updateSelectionBox();
      onShowToast(`Focusing camera on ${selected.name}`);
    }
  };

  const handleSave = () => {
    audioSystem.playUiClick();
    if (buildManager.saveToStorage()) {
      onShowToast('Scene saved to browser storage!', 'success');
    } else {
      onShowToast('Failed to save scene', 'warn');
    }
  };

  return (
    <>
      <div
        style={{
          position: 'fixed',
          top: 'max(10px, env(safe-area-inset-top, 10px))',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 80,
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          padding: '6px 12px',
          borderRadius: '16px',
          backgroundColor: 'rgba(18, 22, 31, 0.92)',
          border: '1.5px solid rgba(0, 162, 255, 0.45)',
          boxShadow: '0 8px 30px rgba(0, 0, 0, 0.65), 0 0 16px rgba(0, 162, 255, 0.25)',
          backdropFilter: 'none',
          maxWidth: '96vw',
          overflowX: 'auto',
        }}
      >
        {/* Switch Mode Button */}
        <button
          onClick={() => {
            audioSystem.playUiClick();
            onToggleBuildMode();
          }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '6px 14px',
            borderRadius: '10px',
            backgroundColor: '#00a2ff',
            color: '#ffffff',
            border: 'none',
            fontSize: '11px',
            fontWeight: 800,
            letterSpacing: '0.04em',
            cursor: 'pointer',
            boxShadow: '0 2px 10px rgba(0, 162, 255, 0.5)',
            transition: 'transform 0.15s ease',
          }}
          className="active:scale-95"
          title="Return to Play Mode"
        >
          <Play size={14} fill="#ffffff" />
          <span>PLAY MODE</span>
        </button>

        <div style={{ width: '1px', height: '22px', backgroundColor: 'rgba(255, 255, 255, 0.15)', margin: '0 2px' }} />

        {/* Panel Toggles */}
        <button
          onClick={() => {
            audioSystem.playUiClick();
            onToggleLeftPanel();
          }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            padding: '6px 10px',
            borderRadius: '8px',
            backgroundColor: isLeftOpen ? 'rgba(0, 162, 255, 0.25)' : 'rgba(255, 255, 255, 0.05)',
            color: isLeftOpen ? '#38bdf8' : '#94a3b8',
            border: '1px solid ' + (isLeftOpen ? 'rgba(0, 162, 255, 0.4)' : 'transparent'),
            fontSize: '11px',
            fontWeight: 700,
            cursor: 'pointer',
          }}
          title="Toggle Left Panel (Explorer / Toolbox)"
        >
          <FolderTree size={14} />
          <span className="hidden sm:inline">Explorer</span>
        </button>

        <button
          onClick={() => {
            audioSystem.playUiClick();
            onToggleRightPanel();
          }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            padding: '6px 10px',
            borderRadius: '8px',
            backgroundColor: isRightOpen ? 'rgba(0, 162, 255, 0.25)' : 'rgba(255, 255, 255, 0.05)',
            color: isRightOpen ? '#38bdf8' : '#94a3b8',
            border: '1px solid ' + (isRightOpen ? 'rgba(0, 162, 255, 0.4)' : 'transparent'),
            fontSize: '11px',
            fontWeight: 700,
            cursor: 'pointer',
          }}
          title="Toggle Right Panel (Inspector / Scripts / Save)"
        >
          <SlidersHorizontal size={14} />
          <span className="hidden sm:inline">Inspector</span>
        </button>

        <div style={{ width: '1px', height: '22px', backgroundColor: 'rgba(255, 255, 255, 0.15)', margin: '0 2px' }} />

        {/* Tools: Select, Move, Rotate, Scale */}
        <div style={{ display: 'flex', gap: '3px', backgroundColor: 'rgba(0, 0, 0, 0.35)', padding: '2px', borderRadius: '8px' }}>
          <button
            onClick={() => onSetTransformMode('select')}
            style={{
              padding: '6px 9px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: transformMode === 'select' ? 'rgba(0, 162, 255, 0.85)' : 'transparent',
              color: transformMode === 'select' ? '#ffffff' : '#94a3b8',
              cursor: 'pointer',
            }}
            title="Select Tool"
          >
            <MousePointer size={15} />
          </button>
          <button
            onClick={() => onSetTransformMode('move')}
            style={{
              padding: '6px 9px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: transformMode === 'move' ? 'rgba(0, 162, 255, 0.85)' : 'transparent',
              color: transformMode === 'move' ? '#ffffff' : '#94a3b8',
              cursor: 'pointer',
            }}
            title="Move Tool"
          >
            <Move size={15} />
          </button>
          <button
            onClick={() => onSetTransformMode('rotate')}
            style={{
              padding: '6px 9px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: transformMode === 'rotate' ? 'rgba(0, 162, 255, 0.85)' : 'transparent',
              color: transformMode === 'rotate' ? '#ffffff' : '#94a3b8',
              cursor: 'pointer',
            }}
            title="Rotate Tool"
          >
            <RotateCw size={15} />
          </button>
          <button
            onClick={() => onSetTransformMode('scale')}
            style={{
              padding: '6px 9px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: transformMode === 'scale' ? 'rgba(0, 162, 255, 0.85)' : 'transparent',
              color: transformMode === 'scale' ? '#ffffff' : '#94a3b8',
              cursor: 'pointer',
            }}
            title="Scale Tool"
          >
            <Maximize2 size={15} />
          </button>
          <button
            onClick={() => onSetTransformMode('fly')}
            style={{
              padding: '6px 9px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: transformMode === 'fly' ? 'rgba(16, 185, 129, 0.85)' : 'transparent',
              color: transformMode === 'fly' ? '#ffffff' : '#94a3b8',
              cursor: 'pointer',
            }}
            title="Free-Fly Navigation"
          >
            <Move size={15} className="rotate-45" />
          </button>
        </div>

        {/* Snapping Menu Button */}
        <div style={{ position: 'relative' }}>
          <button
            onClick={() => setShowSnapMenu(!showSnapMenu)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              padding: '6px 10px',
              borderRadius: '8px',
              backgroundColor: buildManager.gridSnap > 0 ? 'rgba(30, 41, 59, 0.9)' : 'rgba(20, 25, 35, 0.6)',
              border: '1px solid rgba(255, 255, 255, 0.18)',
              color: '#e2e8f0',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
            }}
            title="Grid Snapping Settings"
          >
            <Grid size={14} className="text-cyan-400" />
            <span>{buildManager.gridSnap > 0 ? `${buildManager.gridSnap}m` : 'Off'}</span>
          </button>

          {showSnapMenu && (
            <div
              style={{
                position: 'absolute',
                top: '100%',
                left: 0,
                marginTop: '6px',
                backgroundColor: '#161b26',
                border: '1.5px solid rgba(0, 162, 255, 0.35)',
                borderRadius: '10px',
                padding: '8px',
                display: 'flex',
                flexDirection: 'column',
                gap: '6px',
                minWidth: '160px',
                boxShadow: '0 8px 24px rgba(0, 0, 0, 0.75)',
                zIndex: 100,
              }}
            >
              <div style={{ fontSize: '10px', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase' }}>
                Grid Snap (Move / Scale)
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '4px' }}>
                {([0, 0.25, 0.5, 1.0, 2.0] as GridSnapSetting[]).map((val) => (
                  <button
                    key={val}
                    onClick={() => {
                      buildManager.gridSnap = val;
                      buildManager.updateSnapping();
                      setShowSnapMenu(false);
                      onShowToast(`Grid snap: ${val === 0 ? 'Off' : `${val}m`}`);
                    }}
                    style={{
                      padding: '4px 6px',
                      borderRadius: '6px',
                      backgroundColor: buildManager.gridSnap === val ? '#00a2ff' : 'rgba(255, 255, 255, 0.08)',
                      color: '#ffffff',
                      border: 'none',
                      fontSize: '11px',
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                  >
                    {val === 0 ? 'Off' : `${val}`}
                  </button>
                ))}
              </div>

              <div style={{ fontSize: '10px', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', marginTop: '4px' }}>
                Rotate Snap
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '4px' }}>
                {([0, 15, 45, 90] as RotateSnapSetting[]).map((val) => (
                  <button
                    key={val}
                    onClick={() => {
                      buildManager.rotateSnap = val;
                      buildManager.updateSnapping();
                      setShowSnapMenu(false);
                      onShowToast(`Rotate snap: ${val === 0 ? 'Off' : `${val}°`}`);
                    }}
                    style={{
                      padding: '4px 6px',
                      borderRadius: '6px',
                      backgroundColor: buildManager.rotateSnap === val ? '#00a2ff' : 'rgba(255, 255, 255, 0.08)',
                      color: '#ffffff',
                      border: 'none',
                      fontSize: '11px',
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                  >
                    {val === 0 ? 'Off' : `${val}°`}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Collision Diagnostics Wireframe Toggle */}
        <button
          onClick={() => {
            audioSystem.playUiClick();
            buildManager.toggleCollisionVisibility(!buildManager.showCollisionHelpers);
            onShowToast(
              buildManager.showCollisionHelpers
                ? 'Collision Wireframes ON (Visualizando Caixas Físicas)'
                : 'Collision Wireframes OFF',
              buildManager.showCollisionHelpers ? 'success' : 'info'
            );
          }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            padding: '6px 10px',
            borderRadius: '8px',
            backgroundColor: buildManager.showCollisionHelpers ? 'rgba(239, 68, 68, 0.35)' : 'rgba(20, 25, 35, 0.6)',
            border: buildManager.showCollisionHelpers ? '1.5px solid #ef4444' : '1px solid rgba(255, 255, 255, 0.18)',
            color: buildManager.showCollisionHelpers ? '#fca5a5' : '#94a3b8',
            fontSize: '11px',
            fontWeight: 700,
            cursor: 'pointer',
          }}
          title="Toggle 3D Collision Shapes Wireframe Diagnostics (Caixas de Colisão)"
        >
          <ShieldAlert size={14} className={buildManager.showCollisionHelpers ? 'text-red-400' : 'text-slate-400'} />
          <span>{buildManager.showCollisionHelpers ? 'Colisões ON' : 'Colisões'}</span>
        </button>

        <div style={{ width: '1px', height: '22px', backgroundColor: 'rgba(255, 255, 255, 0.15)', margin: '0 2px' }} />

        {/* Undo & Redo */}
        <button
          onClick={handleUndo}
          disabled={!canUndo}
          style={{
            padding: '6px 8px',
            borderRadius: '6px',
            border: 'none',
            backgroundColor: 'transparent',
            color: canUndo ? '#e2e8f0' : '#475569',
            cursor: canUndo ? 'pointer' : 'not-allowed',
          }}
          title="Undo (Ctrl+Z)"
        >
          <Undo2 size={16} />
        </button>
        <button
          onClick={handleRedo}
          disabled={!canRedo}
          style={{
            padding: '6px 8px',
            borderRadius: '6px',
            border: 'none',
            backgroundColor: 'transparent',
            color: canRedo ? '#e2e8f0' : '#475569',
            cursor: canRedo ? 'pointer' : 'not-allowed',
          }}
          title="Redo (Ctrl+Y)"
        >
          <Redo2 size={16} />
        </button>

        {/* Duplicate & Delete */}
        <button
          onClick={handleDuplicate}
          disabled={!selected || selected.isProtected}
          style={{
            padding: '6px 8px',
            borderRadius: '6px',
            border: 'none',
            backgroundColor: 'transparent',
            color: selected && !selected.isProtected ? '#38bdf8' : '#475569',
            cursor: selected && !selected.isProtected ? 'pointer' : 'not-allowed',
          }}
          title="Duplicate Object"
        >
          <Copy size={16} />
        </button>
        <button
          onClick={handleDelete}
          disabled={!selected || selected.isProtected}
          style={{
            padding: '6px 8px',
            borderRadius: '6px',
            border: 'none',
            backgroundColor: 'transparent',
            color: selected && !selected.isProtected ? '#f87171' : '#475569',
            cursor: selected && !selected.isProtected ? 'pointer' : 'not-allowed',
          }}
          title="Delete Object"
        >
          <Trash2 size={16} />
        </button>

        {/* Focus Camera */}
        <button
          onClick={handleFocus}
          disabled={!selected}
          style={{
            padding: '6px 8px',
            borderRadius: '6px',
            border: 'none',
            backgroundColor: 'transparent',
            color: selected ? '#fbbf24' : '#475569',
            cursor: selected ? 'pointer' : 'not-allowed',
          }}
          title="Focus Camera on Selection"
        >
          <Target size={16} />
        </button>

        {/* Quick Save */}
        <button
          onClick={handleSave}
          style={{
            padding: '6px 10px',
            borderRadius: '8px',
            border: '1px solid rgba(16, 185, 129, 0.4)',
            backgroundColor: 'rgba(16, 185, 129, 0.2)',
            color: '#34d399',
            fontSize: '11px',
            fontWeight: 700,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
          }}
          title="Save Changes"
        >
          <Save size={14} />
          <span>Save</span>
        </button>

      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && selected && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '16px',
          }}
        >
          <div
            style={{
              backgroundColor: '#181e2b',
              border: '1.5px solid rgba(239, 68, 68, 0.5)',
              borderRadius: '14px',
              padding: '20px',
              maxWidth: '360px',
              width: '100%',
              boxShadow: '0 12px 36px rgba(0, 0, 0, 0.8)',
              color: '#ffffff',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
              <Trash2 className="text-red-400" size={20} />
              <h3 style={{ fontSize: '15px', fontWeight: 800 }}>Confirm Deletion</h3>
            </div>
            <p style={{ fontSize: '13px', color: '#cbd5e1', lineHeight: 1.5, marginBottom: '18px' }}>
              Are you sure you want to delete <strong style={{ color: '#f87171' }}>{selected.name}</strong>? This action can be undone with the Undo button.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                style={{
                  padding: '8px 14px',
                  borderRadius: '8px',
                  backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  color: '#ffffff',
                  border: 'none',
                  fontSize: '12px',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                style={{
                  padding: '8px 16px',
                  borderRadius: '8px',
                  backgroundColor: '#ef4444',
                  color: '#ffffff',
                  border: 'none',
                  fontSize: '12px',
                  fontWeight: 800,
                  cursor: 'pointer',
                }}
              >
                Delete Object
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
