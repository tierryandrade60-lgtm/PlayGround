import React, { useState } from 'react';
import {
  Search,
  Box,
  Circle,
  Cylinder,
  Layers,
  Lightbulb,
  Shield,
  Target,
  Zap,
  Lock,
  Trash2,
  Copy,
} from 'lucide-react';
import { BuildModeManager } from '../../game/BuildModeManager';
import { BuildObjectData, BuildObjectType } from '../../game/BuildTypes';
import { audioSystem } from '../../game/AudioSystem';

interface BuildExplorerTabProps {
  buildManager: BuildModeManager;
  onSelectObject: (id: string) => void;
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
}

export const BuildExplorerTab: React.FC<BuildExplorerTabProps> = ({
  buildManager,
  onSelectObject,
  onShowToast,
}) => {
  const [search, setSearch] = useState('');
  const allObjects = buildManager.getObjectsList();
  const selectedId = buildManager.selectedId;

  const filtered = allObjects.filter((obj) =>
    obj.name.toLowerCase().includes(search.toLowerCase()) ||
    obj.type.toLowerCase().includes(search.toLowerCase())
  );

  const userObjects = filtered.filter((o) => o.isUserCreated);
  const dummyObjects = filtered.filter((o) => o.type === 'dummy');
  const structureObjects = filtered.filter((o) => o.type === 'default_structure');
  const coreObjects = filtered.filter((o) => o.isProtected);

  const getIconForType = (type: BuildObjectType) => {
    switch (type) {
      case 'part':
        return <Box size={14} className="text-blue-400" />;
      case 'sphere':
        return <Circle size={14} className="text-emerald-400" />;
      case 'cylinder':
        return <Cylinder size={14} className="text-amber-400" />;
      case 'wedge':
        return <Layers size={14} className="text-purple-400" />;
      case 'plane':
        return <Box size={14} className="text-slate-400" />;
      case 'light':
        return <Lightbulb size={14} className="text-yellow-400" />;
      case 'dummy':
        return <Target size={14} className="text-red-400" />;
      case 'jumppad':
        return <Zap size={14} className="text-cyan-400" />;
      case 'barrier':
        return <Shield size={14} className="text-pink-400" />;
      case 'baseplate':
        return <Layers size={14} className="text-slate-500" />;
      case 'sun_light':
        return <Lightbulb size={14} className="text-amber-300" />;
      case 'stickman':
        return <Target size={14} className="text-cyan-300" />;
      default:
        return <Box size={14} className="text-gray-400" />;
    }
  };

  const renderItem = (obj: BuildObjectData) => {
    const isSelected = obj.id === selectedId;

    return (
      <div
        key={obj.id}
        onClick={() => {
          audioSystem.playUiClick();
          onSelectObject(obj.id);
        }}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '6px 10px',
          borderRadius: '8px',
          backgroundColor: isSelected ? 'rgba(0, 162, 255, 0.22)' : 'rgba(255, 255, 255, 0.03)',
          border: isSelected ? '1px solid rgba(0, 162, 255, 0.6)' : '1px solid transparent',
          marginBottom: '3px',
          cursor: 'pointer',
          transition: 'background-color 0.15s ease',
        }}
        className="hover:bg-slate-800/60"
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0 }}>
          {getIconForType(obj.type)}
          <span
            style={{
              fontSize: '12px',
              fontWeight: isSelected ? 800 : 600,
              color: isSelected ? '#ffffff' : '#cbd5e1',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {obj.name}
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          {obj.isProtected ? (
            <span
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '2px',
                padding: '2px 6px',
                borderRadius: '4px',
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                color: '#94a3b8',
                fontSize: '9px',
                fontWeight: 700,
              }}
              title="Protected System Object"
            >
              <Lock size={10} />
              <span>Core</span>
            </span>
          ) : (
            <div style={{ display: 'flex', gap: '2px' }}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  audioSystem.playUiClick();
                  buildManager.selectObject(obj.id);
                  const id = buildManager.duplicateSelected();
                  if (id) onShowToast('Duplicated', 'success');
                }}
                style={{
                  padding: '3px 5px',
                  borderRadius: '4px',
                  backgroundColor: 'transparent',
                  color: '#94a3b8',
                  border: 'none',
                  cursor: 'pointer',
                }}
                title="Duplicate"
              >
                <Copy size={12} />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  audioSystem.playUiClick();
                  if (buildManager.deleteObject(obj.id)) {
                    onShowToast('Deleted', 'info');
                  }
                }}
                style={{
                  padding: '3px 5px',
                  borderRadius: '4px',
                  backgroundColor: 'transparent',
                  color: '#f87171',
                  border: 'none',
                  cursor: 'pointer',
                }}
                title="Delete"
              >
                <Trash2 size={12} />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: '10px' }}>
      {/* Search Input */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '6px 12px',
          borderRadius: '8px',
          backgroundColor: 'rgba(0, 0, 0, 0.4)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
        }}
      >
        <Search size={14} className="text-slate-400" />
        <input
          type="text"
          placeholder="Filter scene objects..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            backgroundColor: 'transparent',
            border: 'none',
            outline: 'none',
            color: '#ffffff',
            fontSize: '12px',
            width: '100%',
          }}
        />
      </div>

      {/* Explorer Tree Lists */}
      <div style={{ flex: 1, overflowY: 'auto', paddingRight: '4px' }}>
        {userObjects.length > 0 && (
          <div style={{ marginBottom: '14px' }}>
            <div
              style={{
                fontSize: '10px',
                fontWeight: 800,
                color: '#38bdf8',
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                marginBottom: '6px',
                paddingLeft: '4px',
              }}
            >
              User Created ({userObjects.length})
            </div>
            {userObjects.map(renderItem)}
          </div>
        )}

        {dummyObjects.length > 0 && (
          <div style={{ marginBottom: '14px' }}>
            <div
              style={{
                fontSize: '10px',
                fontWeight: 800,
                color: '#f87171',
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                marginBottom: '6px',
                paddingLeft: '4px',
              }}
            >
              Target Dummies ({dummyObjects.length})
            </div>
            {dummyObjects.map(renderItem)}
          </div>
        )}

        {structureObjects.length > 0 && (
          <div style={{ marginBottom: '14px' }}>
            <div
              style={{
                fontSize: '10px',
                fontWeight: 800,
                color: '#94a3b8',
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                marginBottom: '6px',
                paddingLeft: '4px',
              }}
            >
              Testing Structures ({structureObjects.length})
            </div>
            {structureObjects.map(renderItem)}
          </div>
        )}

        {coreObjects.length > 0 && (
          <div>
            <div
              style={{
                fontSize: '10px',
                fontWeight: 800,
                color: '#64748b',
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                marginBottom: '6px',
                paddingLeft: '4px',
              }}
            >
              Core Arena Systems ({coreObjects.length})
            </div>
            {coreObjects.map(renderItem)}
          </div>
        )}

        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '24px 8px', color: '#64748b', fontSize: '12px' }}>
            No objects match &ldquo;{search}&rdquo;
          </div>
        )}
      </div>
    </div>
  );
};
