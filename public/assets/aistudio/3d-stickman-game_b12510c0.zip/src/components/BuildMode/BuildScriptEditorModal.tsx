import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  RotateCcw,
  Undo2,
  Redo2,
  Save,
  Clock,
  Search,
  FileCode,
  Sparkles,
  Download,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { ProjectScriptInfo } from '../../game/RealProjectScripts';
import { audioSystem } from '../../game/AudioSystem';
import { liveConfigManager } from '../../game/LiveConfigManager';

export interface ScriptVersionSnapshot {
  id: string;
  timestamp: number;
  label: string;
  code: string;
}

interface BuildScriptEditorModalProps {
  script: ProjectScriptInfo;
  onClose: () => void;
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
  savedDraft?: string;
  onSaveDraft: (scriptId: string, newCode: string) => void;
}

export const BuildScriptEditorModal: React.FC<BuildScriptEditorModalProps> = ({
  script,
  onClose,
  onShowToast,
  savedDraft,
  onSaveDraft,
}) => {
  const [code, setCode] = useState<string>(savedDraft ?? script.originalSource);
  const [history, setHistory] = useState<string[]>([savedDraft ?? script.originalSource]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showHistoryDrawer, setShowHistoryDrawer] = useState<boolean>(false);
  const [snapshots, setSnapshots] = useState<ScriptVersionSnapshot[]>(() => {
    try {
      const stored = localStorage.getItem(`script_snaps_${script.id}`);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // ignore
    }
    return [
      {
        id: 'initial',
        timestamp: Date.now() - 3600000,
        label: 'Original Source Code',
        code: script.originalSource,
      },
    ];
  });

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const isModified = code !== script.originalSource;

  // Save drafts automatically on change and persist to localStorage
  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    onSaveDraft(script.id, newCode);

    // Debounced history push
    setHistory((prev) => {
      const trimmed = prev.slice(0, historyIndex + 1);
      return [...trimmed, newCode];
    });
    setHistoryIndex((prev) => prev + 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      audioSystem.playUiClick();
      const nextIdx = historyIndex - 1;
      setHistoryIndex(nextIdx);
      const prevCode = history[nextIdx];
      setCode(prevCode);
      onSaveDraft(script.id, prevCode);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      audioSystem.playUiClick();
      const nextIdx = historyIndex + 1;
      setHistoryIndex(nextIdx);
      const nextCode = history[nextIdx];
      setCode(nextCode);
      onSaveDraft(script.id, nextCode);
    }
  };

  const handleCopyAll = () => {
    audioSystem.playUiClick();
    navigator.clipboard
      .writeText(code)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
        const lines = code.split('\n').length;
        onShowToast(`Copied full ${script.name} (${lines} lines)`, 'success');
      })
      .catch(() => {
        onShowToast('Could not access clipboard', 'warn');
      });
  };

  const handleApplyToRunningGame = () => {
    audioSystem.playUiClick();
    onSaveDraft(script.id, code);
    try {
      localStorage.setItem(`script_source_${script.id}`, code);
    } catch {
      // ignore
    }

    const parsedOverrides: Record<string, number> = {};
    const keys = [
      'repulsorDamage',
      'missileCount',
      'missileDamage',
      'heavyMissileDamage',
      'arcaneBlastDamage',
      'darkDrainDps',
      'arcaneChokeDuration',
      'groundMaxSpeed',
      'flightMaxSpeed',
      'dashSpeed',
      'dashCooldown',
      'dashDuration',
      'jumpPadBounceMultiplier',
      'sunLightIntensity',
    ];

    keys.forEach((key) => {
      const regex = new RegExp(`\\b${key}\\s*[:=]\\s*([0-9]+(?:\\.[0-9]+)?)`, 'i');
      const match = code.match(regex);
      if (match && match[1]) {
        const val = parseFloat(match[1]);
        if (!isNaN(val)) {
          parsedOverrides[key] = val;
        }
      }
    });

    if (Object.keys(parsedOverrides).length > 0) {
      liveConfigManager.update(parsedOverrides);
      onShowToast(`Applied ${Object.keys(parsedOverrides).length} parameters from ${script.name} to running game!`, 'success');
    } else {
      onShowToast(`Script ${script.name} saved and compiled into running project!`, 'success');
    }
  };

  const handleCreateSnapshot = () => {
    audioSystem.playUiClick();
    const snap: ScriptVersionSnapshot = {
      id: `snap_${Date.now()}`,
      timestamp: Date.now(),
      label: `Version ${snapshots.length + 1} (${new Date().toLocaleTimeString()})`,
      code,
    };
    const updated = [snap, ...snapshots];
    setSnapshots(updated);
    try {
      localStorage.setItem(`script_snaps_${script.id}`, JSON.stringify(updated));
    } catch {
      // ignore
    }
    onShowToast(`Saved version snapshot "${snap.label}"`, 'success');
  };

  const handleRestoreSnapshot = (snap: ScriptVersionSnapshot) => {
    audioSystem.playUiClick();
    handleCodeChange(snap.code);
    setShowHistoryDrawer(false);
    onShowToast(`Restored snapshot: ${snap.label}`, 'info');
  };

  const handleRestoreOriginal = () => {
    audioSystem.playUiClick();
    handleCodeChange(script.originalSource);
    onShowToast(`Restored original source for ${script.name}`, 'info');
  };

  const handleDownload = () => {
    audioSystem.playUiClick();
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const fileName = script.filePath.split('/').pop() || `${script.id}.${script.fileExtension}`;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`Exported ${fileName}`, 'success');
  };

  const lines = code.split('\n');

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(5, 8, 15, 0.85)',
        backdropFilter: 'blur(8px)',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 'max(10px, env(safe-area-inset-top, 10px)) max(10px, env(safe-area-inset-right, 10px)) max(10px, env(safe-area-inset-bottom, 10px)) max(10px, env(safe-area-inset-left, 10px))',
        pointerEvents: 'auto',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '1080px',
          height: '92vh',
          backgroundColor: '#0d111a',
          borderRadius: '16px',
          border: '1.5px solid rgba(56, 189, 248, 0.35)',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.85)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Header Bar */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '10px 16px',
            backgroundColor: '#131824',
            borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', minWidth: 0 }}>
            <FileCode size={18} className="text-cyan-400 shrink-0" />
            <div style={{ minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <h2 style={{ fontSize: '14px', fontWeight: 800, color: '#ffffff', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {script.name}
                </h2>
                <span
                  style={{
                    fontSize: '10px',
                    padding: '2px 8px',
                    borderRadius: '10px',
                    backgroundColor: 'rgba(56, 189, 248, 0.15)',
                    color: '#38bdf8',
                    fontWeight: 700,
                  }}
                >
                  {script.category}
                </span>
                {isModified ? (
                  <span
                    style={{
                      fontSize: '10px',
                      padding: '2px 8px',
                      borderRadius: '10px',
                      backgroundColor: 'rgba(245, 158, 11, 0.2)',
                      color: '#fbbf24',
                      fontWeight: 700,
                    }}
                  >
                    ● Modificado (Salvo no Projeto)
                  </span>
                ) : (
                  <span
                    style={{
                      fontSize: '10px',
                      padding: '2px 8px',
                      borderRadius: '10px',
                      backgroundColor: 'rgba(16, 185, 129, 0.15)',
                      color: '#34d399',
                      fontWeight: 700,
                    }}
                  >
                    ✓ Original
                  </span>
                )}
              </div>
              <div style={{ fontSize: '10px', color: '#64748b' }}>
                {script.filePath} · {lines.length} linhas
              </div>
            </div>
          </div>

          {/* Close X Button */}
          <button
            onClick={() => {
              audioSystem.playUiClick();
              onClose();
            }}
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '8px',
              backgroundColor: 'rgba(255, 255, 255, 0.08)',
              color: '#94a3b8',
              border: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
            className="hover:bg-red-500/20 hover:text-red-400"
            title="Fechar Editor"
          >
            <X size={18} />
          </button>
        </div>

        {/* Action Controls Toolbar */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '8px 16px',
            backgroundColor: '#10141f',
            borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
            gap: '8px',
            flexWrap: 'wrap',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            {/* Prominent Copy All Code Button */}
            <button
              onClick={handleCopyAll}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '7px 14px',
                borderRadius: '8px',
                backgroundColor: copied ? '#10b981' : '#00a2ff',
                color: '#ffffff',
                border: 'none',
                fontSize: '12px',
                fontWeight: 800,
                cursor: 'pointer',
                boxShadow: '0 2px 8px rgba(0, 162, 255, 0.4)',
                transition: 'all 0.15s ease',
              }}
              className="active:scale-95 hover:brightness-110"
              title="Copiar Todo o Código Fonte Completo"
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
              <span>{copied ? 'CÓDIGO COPIADO!' : 'COPIAR TODO O CÓDIGO'}</span>
            </button>

            {/* Apply to Running Game Button */}
            <button
              onClick={handleApplyToRunningGame}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '7px 14px',
                borderRadius: '8px',
                backgroundColor: '#10b981',
                color: '#ffffff',
                border: 'none',
                fontSize: '12px',
                fontWeight: 800,
                cursor: 'pointer',
                boxShadow: '0 2px 8px rgba(16, 185, 129, 0.4)',
                transition: 'all 0.15s ease',
              }}
              className="active:scale-95 hover:brightness-110"
              title="Salvar e Aplicar Alterações ao Jogo em Execução (Play Test)"
            >
              <Sparkles size={14} />
              <span>APLICAR AO JOGO</span>
            </button>

            {/* Undo / Redo */}
            <button
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                padding: '7px 10px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                color: historyIndex > 0 ? '#ffffff' : '#475569',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: historyIndex > 0 ? 'pointer' : 'not-allowed',
              }}
              title="Desfazer Edição"
            >
              <Undo2 size={14} />
              <span>Desfazer</span>
            </button>

            <button
              onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                padding: '7px 10px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                color: historyIndex < history.length - 1 ? '#ffffff' : '#475569',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: historyIndex < history.length - 1 ? 'pointer' : 'not-allowed',
              }}
              title="Refazer Edição"
            >
              <Redo2 size={14} />
              <span>Refazer</span>
            </button>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            {/* Version Snapshot */}
            <button
              onClick={handleCreateSnapshot}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                padding: '7px 10px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                color: '#38bdf8',
                border: '1px solid rgba(56, 189, 248, 0.25)',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
              title="Criar Ponto de Restauração / Versão"
            >
              <Save size={13} />
              <span>Salvar Versão</span>
            </button>

            {/* Version History Toggle */}
            <button
              onClick={() => setShowHistoryDrawer(!showHistoryDrawer)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                padding: '7px 10px',
                borderRadius: '8px',
                backgroundColor: showHistoryDrawer ? 'rgba(56, 189, 248, 0.2)' : 'rgba(255, 255, 255, 0.06)',
                color: showHistoryDrawer ? '#38bdf8' : '#e2e8f0',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
              title="Histórico de Versões"
            >
              <Clock size={13} />
              <span>Histórico ({snapshots.length})</span>
            </button>

            {/* Export */}
            <button
              onClick={handleDownload}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                padding: '7px 10px',
                borderRadius: '8px',
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                color: '#cbd5e1',
                border: 'none',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
              title="Baixar Arquivo"
            >
              <Download size={13} />
              <span>Exportar</span>
            </button>

            {/* Restore Original */}
            {isModified && (
              <button
                onClick={handleRestoreOriginal}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '7px 10px',
                  borderRadius: '8px',
                  backgroundColor: 'rgba(239, 68, 68, 0.15)',
                  color: '#f87171',
                  border: '1px solid rgba(239, 68, 68, 0.3)',
                  fontSize: '11px',
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
                title="Restaurar Código Original do Jogo"
              >
                <RotateCcw size={13} />
                <span>Restaurar Original</span>
              </button>
            )}
          </div>
        </div>

        {/* Main Editor Body + Optional History Sidebar */}
        <div style={{ flex: 1, display: 'flex', minHeight: 0, position: 'relative' }}>
          {/* Code Area with Line Numbers */}
          <div style={{ flex: 1, display: 'flex', minHeight: 0, backgroundColor: '#090d14' }}>
            {/* Line Number Gutter */}
            <div
              style={{
                width: '46px',
                backgroundColor: '#080b11',
                borderRight: '1px solid rgba(255, 255, 255, 0.06)',
                padding: '12px 6px',
                textAlign: 'right',
                userSelect: 'none',
                color: '#475569',
                fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                fontSize: '11px',
                lineHeight: '1.6',
                overflowY: 'hidden',
              }}
            >
              {lines.map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>

            {/* Editable Textarea */}
            <textarea
              ref={textareaRef}
              value={code}
              onChange={(e) => handleCodeChange(e.target.value)}
              onKeyDown={(e) => {
                // Tab indentation support
                if (e.key === 'Tab') {
                  e.preventDefault();
                  const start = e.currentTarget.selectionStart;
                  const end = e.currentTarget.selectionEnd;
                  const newCode = code.substring(0, start) + '  ' + code.substring(end);
                  handleCodeChange(newCode);
                  setTimeout(() => {
                    if (textareaRef.current) {
                      textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 2;
                    }
                  }, 0);
                }
              }}
              spellCheck={false}
              style={{
                flex: 1,
                height: '100%',
                backgroundColor: 'transparent',
                color: '#e2e8f0',
                border: 'none',
                padding: '12px 14px',
                fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                fontSize: '12px',
                lineHeight: '1.6',
                outline: 'none',
                resize: 'none',
                whiteSpace: 'pre',
                overflowX: 'auto',
                overflowY: 'auto',
              }}
            />
          </div>

          {/* Version History Drawer (Right) */}
          {showHistoryDrawer && (
            <div
              style={{
                width: '280px',
                backgroundColor: '#121724',
                borderLeft: '1px solid rgba(255, 255, 255, 0.08)',
                display: 'flex',
                flexDirection: 'column',
                overflowY: 'auto',
                padding: '12px',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span style={{ fontSize: '12px', fontWeight: 800, color: '#ffffff' }}>Versões Salvas</span>
                <button
                  onClick={() => setShowHistoryDrawer(false)}
                  style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}
                >
                  <X size={14} />
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {snapshots.map((snap) => (
                  <div
                    key={snap.id}
                    style={{
                      padding: '10px',
                      borderRadius: '8px',
                      backgroundColor: 'rgba(255, 255, 255, 0.04)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px',
                    }}
                  >
                    <div style={{ fontSize: '11px', fontWeight: 700, color: '#ffffff' }}>{snap.label}</div>
                    <div style={{ fontSize: '10px', color: '#64748b' }}>
                      {new Date(snap.timestamp).toLocaleString()} · {snap.code.split('\n').length} linhas
                    </div>
                    <button
                      onClick={() => handleRestoreSnapshot(snap)}
                      style={{
                        marginTop: '4px',
                        padding: '5px 8px',
                        borderRadius: '6px',
                        backgroundColor: '#00a2ff',
                        color: '#ffffff',
                        border: 'none',
                        fontSize: '10px',
                        fontWeight: 700,
                        cursor: 'pointer',
                      }}
                    >
                      Restaurar esta Versão
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Info */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '8px 16px',
            backgroundColor: '#0c0f17',
            borderTop: '1px solid rgba(255, 255, 255, 0.06)',
            fontSize: '11px',
            color: '#94a3b8',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ color: '#38bdf8' }}>✓ Edições mantidas na sessão de trabalho</span>
            <span>·</span>
            <span>Copie e cole para assistentes de IA externos</span>
          </div>

          <button
            onClick={() => {
              audioSystem.playUiClick();
              onClose();
            }}
            style={{
              padding: '6px 14px',
              borderRadius: '8px',
              backgroundColor: '#1e293b',
              color: '#ffffff',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            Concluir & Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
