import React, { useState, useRef, useEffect } from 'react';
import {
  Code,
  Sliders,
  Copy,
  Download,
  Upload,
  RotateCcw,
  Check,
  FileCode,
  Info,
  Plus,
  Trash2,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import { ProjectScriptInfo } from '../../game/RealProjectScripts';
import { liveConfigManager, LiveGameConfig } from '../../game/LiveConfigManager';
import { scriptRuntimeEngine } from '../../game/ScriptRuntimeEngine';
import { audioSystem } from '../../game/AudioSystem';
import { BuildScriptEditorModal } from './BuildScriptEditorModal';

interface BuildScriptsTabProps {
  onShowToast: (text: string, type?: 'info' | 'success' | 'warn') => void;
}

export const BuildScriptsTab: React.FC<BuildScriptsTabProps> = ({ onShowToast }) => {
  const [subTab, setSubTab] = useState<'source' | 'tuning'>('source');
  const scripts = scriptRuntimeEngine.getScripts();
  const [selectedScriptId, setSelectedScriptId] = useState<string>(scripts[0]?.id ?? 'agatha-abilities');
  const [editingScript, setEditingScript] = useState<ProjectScriptInfo | null>(null);
  const [userDrafts, setUserDrafts] = useState<Record<string, string>>(() => {
    try {
      const stored = localStorage.getItem('user_script_drafts');
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    return {};
  });
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  const activeScript = scripts.find((s) => s.id === selectedScriptId) || scripts[0] || {
    id: 'fallback',
    name: 'Fallback Script',
    filePath: '/src/game/Fallback.ts',
    category: 'Combat & Interactions',
    summary: 'Fallback script',
    originalSource: '// Empty source',
    fileExtension: 'ts',
  };

  const currentCode = userDrafts[activeScript.id] ?? activeScript.originalSource;
  const hasUnsavedDraft = userDrafts[activeScript.id] !== undefined && userDrafts[activeScript.id] !== activeScript.originalSource;

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSaveDraft = (scriptId: string, newCode: string) => {
    setUserDrafts((prev) => {
      const updated = { ...prev, [scriptId]: newCode };
      try {
        localStorage.setItem('user_script_drafts', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
    scriptRuntimeEngine.saveScriptCode(scriptId, newCode);
    scriptRuntimeEngine.applyScriptToGame(scriptId, newCode);
  };

  // Live Tuning Config State
  const [liveConfig, setLiveConfig] = useState<LiveGameConfig>(liveConfigManager.get());

  useEffect(() => {
    const unsub = liveConfigManager.subscribe((cfg) => {
      setLiveConfig(cfg);
    });
    return unsub;
  }, []);

  const handleCopyAll = () => {
    audioSystem.playUiClick();
    navigator.clipboard.writeText(currentCode).then(() => {
      onShowToast(`Copied ${activeScript.name} (${currentCode.split('\n').length} lines)`, 'success');
    }).catch(() => {
      onShowToast('Clipboard permission denied', 'warn');
    });
  };

  const handleSelectAll = () => {
    audioSystem.playUiClick();
    if (textareaRef.current) {
      textareaRef.current.select();
      onShowToast('Selected all code in viewer');
    }
  };

  const handleExportFile = () => {
    audioSystem.playUiClick();
    const blob = new Blob([currentCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const fileName = activeScript.filePath.split('/').pop() || `${activeScript.id}.${activeScript.fileExtension}`;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast(`Downloaded ${fileName}`, 'success');
  };

  const handleApplyReplacement = () => {
    audioSystem.playUiClick();
    handleSaveDraft(activeScript.id, currentCode);
    scriptRuntimeEngine.applyScriptToGame(activeScript.id, currentCode);
    onShowToast(`Applied ${activeScript.name} to running game!`, 'success');
  };

  const handleRestoreOriginal = () => {
    audioSystem.playUiClick();
    setUserDrafts((prev) => {
      const copy = { ...prev };
      delete copy[activeScript.id];
      return copy;
    });
    scriptRuntimeEngine.saveScriptCode(activeScript.id, activeScript.originalSource);
    scriptRuntimeEngine.applyScriptToGame(activeScript.id, activeScript.originalSource);
    onShowToast(`Restored original ${activeScript.name}`, 'info');
  };

  const handleCreateNewScript = () => {
    audioSystem.playUiClick();
    const name = prompt('Enter name for new script (e.g. CustomWeapon.ts):', 'CustomBehavior.ts');
    if (!name) return;
    const filePath = `/src/game/${name.replace(/\s+/g, '')}`;
    const initialCode = `/**\n * ${name}\n * Custom runtime script executed in Play Test.\n */\nfunction onUpdate(gameScene, dt) {\n  // Custom logic executed every frame\n}\n`;
    const newScript = scriptRuntimeEngine.createScript(name, filePath, 'Combat & Interactions', initialCode);
    setSelectedScriptId(newScript.id);
    onShowToast(`Created and registered new script ${name}!`, 'success');
  };

  const handleDeleteCurrentScript = () => {
    audioSystem.playUiClick();
    if (confirm(`Are you sure you want to delete ${activeScript.name}?`)) {
      scriptRuntimeEngine.deleteScript(activeScript.id);
      const remaining = scriptRuntimeEngine.getScripts();
      if (remaining.length > 0) {
        setSelectedScriptId(remaining[0].id);
      }
      onShowToast(`Deleted script ${activeScript.name}`, 'info');
    }
  };

  const handleLiveConfigChange = <K extends keyof LiveGameConfig>(key: K, value: LiveGameConfig[K]) => {
    const updated = { ...liveConfig, [key]: value };
    setLiveConfig(updated);
    liveConfigManager.update(updated);
  };

  // Group scripts logically into clean categories
  const groups = [
    { title: '⚡ Character Powers & Abilities', categories: ['Agatha', 'Iron Man'] },
    { title: '🎮 UI, Controls & HUD', categories: ['UI & Controls'] },
    { title: '⚙️ Core Engine & Systems', categories: ['Target System', 'Characters', 'Combat & Interactions', 'Movement & Camera', 'Audio & Sound', 'Settings & State'] },
  ];

  const toggleCategory = (title: string) => {
    audioSystem.playUiClick();
    setCollapsedCategories((prev) => ({ ...prev, [title]: !prev[title] }));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: '12px', padding: '4px' }}>
      {/* Sub-tab navigation */}
      <div style={{ display: 'flex', gap: '8px', borderBottom: '1px solid rgba(255, 255, 255, 0.1)', paddingBottom: '10px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={() => {
              audioSystem.playUiClick();
              setSubTab('source');
            }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 14px',
              borderRadius: '8px',
              border: 'none',
              backgroundColor: subTab === 'source' ? '#00a2ff' : 'rgba(255, 255, 255, 0.05)',
              color: '#ffffff',
              fontSize: '12px',
              fontWeight: 800,
              cursor: 'pointer',
            }}
          >
            <Code size={15} />
            <span>Scripts ({scripts.length})</span>
          </button>

          <button
            onClick={() => {
              audioSystem.playUiClick();
              setSubTab('tuning');
            }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 14px',
              borderRadius: '8px',
              border: 'none',
              backgroundColor: subTab === 'tuning' ? '#00a2ff' : 'rgba(255, 255, 255, 0.05)',
              color: '#ffffff',
              fontSize: '12px',
              fontWeight: 800,
              cursor: 'pointer',
            }}
          >
            <Sliders size={15} />
            <span>Live Tuning</span>
          </button>
        </div>

        {subTab === 'source' && (
          <button
            onClick={handleCreateNewScript}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '7px 12px',
              borderRadius: '8px',
              backgroundColor: '#10b981',
              color: '#ffffff',
              border: 'none',
              fontSize: '11px',
              fontWeight: 800,
              cursor: 'pointer',
              boxShadow: '0 2px 8px rgba(16, 185, 129, 0.3)',
            }}
            title="Create New Custom Script"
          >
            <Plus size={14} />
            <span>New Script</span>
          </button>
        )}
      </div>

      {subTab === 'source' ? (
        <div style={{ display: 'flex', gap: '14px', flex: 1, minHeight: 0 }}>
          {/* Left: Categorized Script Sidebar */}
          <div
            style={{
              width: '230px',
              overflowY: 'auto',
              paddingRight: '6px',
              borderRight: '1px solid rgba(255, 255, 255, 0.08)',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
            }}
          >
            {groups.map((group) => {
              const groupScripts = scripts.filter((s) => group.categories.includes(s.category));
              if (groupScripts.length === 0) return null;
              const isCollapsed = collapsedCategories[group.title];

              return (
                <div key={group.title} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div
                    onClick={() => toggleCategory(group.title)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      fontSize: '11px',
                      fontWeight: 800,
                      color: '#94a3b8',
                      cursor: 'pointer',
                      padding: '4px 6px',
                      borderRadius: '6px',
                      backgroundColor: 'rgba(255, 255, 255, 0.02)',
                    }}
                  >
                    <span>{group.title}</span>
                    {isCollapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                  </div>

                  {!isCollapsed && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', paddingLeft: '4px' }}>
                      {groupScripts.map((script) => {
                        const isSelected = script.id === activeScript.id;
                        const isModified = userDrafts[script.id] !== undefined;

                        return (
                          <div
                            key={script.id}
                            onClick={() => {
                              audioSystem.playUiClick();
                              setSelectedScriptId(script.id);
                            }}
                            style={{
                              padding: '9px 12px',
                              borderRadius: '9px',
                              backgroundColor: isSelected ? 'rgba(0, 162, 255, 0.25)' : 'rgba(255, 255, 255, 0.04)',
                              border: isSelected ? '1px solid rgba(0, 162, 255, 0.6)' : '1px solid rgba(255, 255, 255, 0.06)',
                              cursor: 'pointer',
                              transition: 'all 0.15s ease',
                            }}
                            className="hover:bg-slate-800/70"
                          >
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3px' }}>
                              <span style={{ fontSize: '11px', fontWeight: 800, color: isSelected ? '#ffffff' : '#e2e8f0' }}>
                                {script.name}
                              </span>
                              {isModified && (
                                <span
                                  style={{
                                    width: '7px',
                                    height: '7px',
                                    borderRadius: '50%',
                                    backgroundColor: '#f59e0b',
                                  }}
                                  title="Modified draft"
                                />
                              )}
                            </div>
                            <div style={{ fontSize: '10px', color: '#64748b' }}>
                              {script.filePath.split('/').pop()}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Right: Code Viewer & Spacious Action Toolbar */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0, gap: '10px' }}>
            {/* Header info & spacious buttons */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                paddingBottom: '10px',
                borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
                flexWrap: 'wrap',
                gap: '8px',
              }}
            >
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: '13px', fontWeight: 800, color: '#ffffff' }}>
                    {activeScript.name}
                  </span>
                  <span style={{ fontSize: '10px', padding: '2px 8px', borderRadius: '6px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#94a3b8' }}>
                    {activeScript.filePath}
                  </span>
                  <span style={{ fontSize: '10px', color: '#64748b' }}>
                    ({currentCode.split('\n').length} lines)
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
                <button
                  onClick={() => {
                    audioSystem.playUiClick();
                    setEditingScript(activeScript);
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '7px 12px',
                    borderRadius: '8px',
                    backgroundColor: '#00a2ff',
                    color: '#ffffff',
                    border: 'none',
                    fontSize: '11px',
                    fontWeight: 800,
                    cursor: 'pointer',
                    boxShadow: '0 2px 8px rgba(0, 162, 255, 0.4)',
                  }}
                  title="Abrir no Editor Completo"
                >
                  <FileCode size={14} />
                  <span>FULL EDITOR</span>
                </button>

                <button
                  onClick={handleCopyAll}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '7px 10px',
                    borderRadius: '8px',
                    backgroundColor: 'rgba(255, 255, 255, 0.08)',
                    color: '#ffffff',
                    border: 'none',
                    fontSize: '11px',
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                  title="Copy Code"
                >
                  <Copy size={14} />
                  <span>Copy</span>
                </button>

                <button
                  onClick={handleExportFile}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '7px 10px',
                    borderRadius: '8px',
                    backgroundColor: 'rgba(255, 255, 255, 0.08)',
                    color: '#38bdf8',
                    border: 'none',
                    fontSize: '11px',
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                  title="Download File"
                >
                  <Download size={14} />
                  <span>Export</span>
                </button>

                <button
                  onClick={handleApplyReplacement}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '7px 12px',
                    borderRadius: '8px',
                    backgroundColor: '#10b981',
                    color: '#ffffff',
                    border: 'none',
                    fontSize: '11px',
                    fontWeight: 800,
                    cursor: 'pointer',
                    boxShadow: '0 2px 8px rgba(16, 185, 129, 0.4)',
                  }}
                  title="Apply and Compile into Game"
                >
                  <Upload size={14} />
                  <span>Apply</span>
                </button>

                {hasUnsavedDraft && (
                  <button
                    onClick={handleRestoreOriginal}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '5px',
                      padding: '7px 10px',
                      borderRadius: '8px',
                      backgroundColor: 'rgba(245, 158, 11, 0.2)',
                      color: '#fbbf24',
                      border: '1px solid rgba(245, 158, 11, 0.4)',
                      fontSize: '11px',
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                    title="Restore Original"
                  >
                    <RotateCcw size={14} />
                    <span>Restore</span>
                  </button>
                )}

                <button
                  onClick={handleDeleteCurrentScript}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '7px 10px',
                    borderRadius: '8px',
                    backgroundColor: 'rgba(239, 68, 68, 0.2)',
                    color: '#f87171',
                    border: '1px solid rgba(239, 68, 68, 0.4)',
                    fontSize: '11px',
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                  title="Delete Script"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

            {/* Code Box */}
            <div style={{ flex: 1, minHeight: 0, position: 'relative' }}>
              <textarea
                ref={textareaRef}
                readOnly
                value={currentCode}
                style={{
                  width: '100%',
                  height: '100%',
                  backgroundColor: '#0c0f17',
                  color: '#e2e8f0',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '10px',
                  padding: '12px',
                  fontSize: '11px',
                  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                  lineHeight: 1.5,
                  resize: 'none',
                  outline: 'none',
                  whiteSpace: 'pre',
                  overflowX: 'auto',
                }}
              />
            </div>
          </div>
        </div>
      ) : (
        /* Live Game Tuning Subtab */
        <div style={{ flex: 1, overflowY: 'auto', paddingRight: '6px' }}>
          <div
            style={{
              padding: '10px 14px',
              borderRadius: '8px',
              backgroundColor: 'rgba(0, 162, 255, 0.1)',
              border: '1px solid rgba(0, 162, 255, 0.25)',
              marginBottom: '16px',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
            }}
          >
            <Info size={18} className="text-cyan-400" />
            <p style={{ fontSize: '11px', color: '#cbd5e1', margin: 0, lineHeight: 1.4 }}>
              <strong>Live Runtime Tuning:</strong> Changes to these configuration sliders apply immediately to the running 3D game without resetting your progress or requiring full file re-compilation.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
            {/* Locomotion & Physics */}
            <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.03)', padding: '12px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.08)' }}>
              <div style={{ fontSize: '12px', fontWeight: 800, color: '#38bdf8', marginBottom: '10px', textTransform: 'uppercase' }}>
                Player Locomotion
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Ground Walk Speed</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.groundMaxSpeed} m/s</strong>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="18"
                    step="0.5"
                    value={liveConfig.groundMaxSpeed}
                    onChange={(e) => handleLiveConfigChange('groundMaxSpeed', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Flight Max Speed</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.flightMaxSpeed} m/s</strong>
                  </div>
                  <input
                    type="range"
                    min="3"
                    max="22"
                    step="0.5"
                    value={liveConfig.flightMaxSpeed}
                    onChange={(e) => handleLiveConfigChange('flightMaxSpeed', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Dash Speed</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.dashSpeed} m/s</strong>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="35"
                    step="1"
                    value={liveConfig.dashSpeed}
                    onChange={(e) => handleLiveConfigChange('dashSpeed', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Dash Cooldown</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.dashCooldown}s</strong>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="6.0"
                    step="0.2"
                    value={liveConfig.dashCooldown}
                    onChange={(e) => handleLiveConfigChange('dashCooldown', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>
              </div>
            </div>

            {/* Combat Stats: Iron Man */}
            <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.03)', padding: '12px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.08)' }}>
              <div style={{ fontSize: '12px', fontWeight: 800, color: '#fbbf24', marginBottom: '10px', textTransform: 'uppercase' }}>
                Iron Man Tech Powers
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Repulsor Shot Damage</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.repulsorDamage} HP</strong>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    step="2"
                    value={liveConfig.repulsorDamage}
                    onChange={(e) => handleLiveConfigChange('repulsorDamage', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Micro-Missile Volley Count</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.missileCount} missiles</strong>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="12"
                    step="1"
                    value={liveConfig.missileCount}
                    onChange={(e) => handleLiveConfigChange('missileCount', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Heavy Unibeam Damage</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.heavyMissileDamage} HP</strong>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="180"
                    step="5"
                    value={liveConfig.heavyMissileDamage}
                    onChange={(e) => handleLiveConfigChange('heavyMissileDamage', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>
              </div>
            </div>

            {/* Combat Stats: Agatha Harkness */}
            <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.03)', padding: '12px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.08)' }}>
              <div style={{ fontSize: '12px', fontWeight: 800, color: '#c084fc', marginBottom: '10px', textTransform: 'uppercase' }}>
                Agatha Harkness Dark Magic
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Arcane Blast Damage</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.arcaneBlastDamage} HP</strong>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="120"
                    step="2"
                    value={liveConfig.arcaneBlastDamage}
                    onChange={(e) => handleLiveConfigChange('arcaneBlastDamage', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Dark Drain DPS</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.darkDrainDps} HP/s</strong>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="80"
                    step="2"
                    value={liveConfig.darkDrainDps}
                    onChange={(e) => handleLiveConfigChange('darkDrainDps', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Arcane Choke Duration</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.arcaneChokeDuration}s</strong>
                  </div>
                  <input
                    type="range"
                    min="1.5"
                    max="6.0"
                    step="0.5"
                    value={liveConfig.arcaneChokeDuration}
                    onChange={(e) => handleLiveConfigChange('arcaneChokeDuration', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>
              </div>
            </div>

            {/* Arena Environment */}
            <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.03)', padding: '12px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.08)' }}>
              <div style={{ fontSize: '12px', fontWeight: 800, color: '#34d399', marginBottom: '10px', textTransform: 'uppercase' }}>
                Environment & Lighting
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: '11px', color: '#cbd5e1' }}>Sky Fog Color</span>
                  <input
                    type="color"
                    value={liveConfig.skyColor}
                    onChange={(e) => handleLiveConfigChange('skyColor', e.target.value)}
                    style={{ width: '32px', height: '22px', border: 'none', borderRadius: '4px', background: 'none', cursor: 'pointer' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Sun Light Intensity</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.sunLightIntensity}</strong>
                  </div>
                  <input
                    type="range"
                    min="0.4"
                    max="2.5"
                    step="0.05"
                    value={liveConfig.sunLightIntensity}
                    onChange={(e) => handleLiveConfigChange('sunLightIntensity', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                    <span>Jump Pad Global Multiplier</span>
                    <strong style={{ color: '#ffffff' }}>{liveConfig.jumpPadBounceMultiplier}x</strong>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.5"
                    step="0.1"
                    value={liveConfig.jumpPadBounceMultiplier}
                    onChange={(e) => handleLiveConfigChange('jumpPadBounceMultiplier', Number(e.target.value))}
                    style={{ width: '100%' }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Full-Screen / Dedicated Mobile-Optimized Script Editor Modal */}
      {editingScript && (
        <BuildScriptEditorModal
          script={editingScript}
          onClose={() => setEditingScript(null)}
          onShowToast={onShowToast}
          savedDraft={userDrafts[editingScript.id]}
          onSaveDraft={handleSaveDraft}
        />
      )}
    </div>
  );
};
