import React from 'react';
import {
  Move,
  RotateCw,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Plus,
  Minus,
} from 'lucide-react';
import { TransformMode } from '../../game/BuildTypes';
import { BuildModeManager } from '../../game/BuildModeManager';
import { audioSystem } from '../../game/AudioSystem';

interface BuildGizmoOverlayProps {
  buildManager: BuildModeManager;
  transformMode: TransformMode;
}

export const BuildGizmoOverlay: React.FC<BuildGizmoOverlayProps> = ({
  buildManager,
  transformMode,
}) => {
  const selected = buildManager.getSelectedData();
  if (!selected || selected.isProtected || transformMode === 'select') {
    return null;
  }

  const handleNudgePos = (axis: 'x' | 'y' | 'z', dir: 1 | -1) => {
    audioSystem.playUiClick();
    buildManager.nudgePosition(axis, dir);
  };

  const handleNudgeRot = (axis: 'x' | 'y' | 'z', dir: 1 | -1) => {
    audioSystem.playUiClick();
    buildManager.nudgeRotation(axis, dir);
  };

  const handleNudgeScale = (dir: 1 | -1) => {
    audioSystem.playUiClick();
    buildManager.nudgeScale(dir, true);
  };

  return (
    <div
      style={{
        position: 'fixed',
        right: '16px',
        top: '72px',
        zIndex: 70,
        backgroundColor: 'rgba(18, 22, 31, 0.88)',
        border: '1.5px solid rgba(0, 162, 255, 0.35)',
        borderRadius: '12px',
        padding: '8px 10px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '6px',
        boxShadow: '0 8px 24px rgba(0, 0, 0, 0.55)',
        backdropFilter: 'none',
      }}
    >
      <div style={{ fontSize: '10px', fontWeight: 800, color: '#38bdf8', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {transformMode === 'move' ? 'Move Nudge' : transformMode === 'rotate' ? 'Rotate Nudge' : 'Scale Nudge'}
      </div>

      {transformMode === 'move' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {/* Y Axis (Up/Down) */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
            <span style={{ fontSize: '10px', fontWeight: 800, color: '#10b981', width: '14px' }}>Y</span>
            <button
              onClick={() => handleNudgePos('y', 1)}
              style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
              title="Move Up (+Y)"
            >
              <ChevronUp size={14} />
            </button>
            <button
              onClick={() => handleNudgePos('y', -1)}
              style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
              title="Move Down (-Y)"
            >
              <ChevronDown size={14} />
            </button>
          </div>

          {/* X Axis (Left/Right) */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
            <span style={{ fontSize: '10px', fontWeight: 800, color: '#ef4444', width: '14px' }}>X</span>
            <button
              onClick={() => handleNudgePos('x', -1)}
              style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
              title="Move Left (-X)"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              onClick={() => handleNudgePos('x', 1)}
              style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
              title="Move Right (+X)"
            >
              <ChevronRight size={14} />
            </button>
          </div>

          {/* Z Axis (Forward/Backward) */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
            <span style={{ fontSize: '10px', fontWeight: 800, color: '#3b82f6', width: '14px' }}>Z</span>
            <button
              onClick={() => handleNudgePos('z', -1)}
              style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
              title="Move Forward (-Z)"
            >
              <Plus size={14} />
            </button>
            <button
              onClick={() => handleNudgePos('z', 1)}
              style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
              title="Move Backward (+Z)"
            >
              <Minus size={14} />
            </button>
          </div>
        </div>
      )}

      {transformMode === 'rotate' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {(['y', 'x', 'z'] as const).map((axis) => (
            <div key={axis} style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span
                style={{
                  fontSize: '10px',
                  fontWeight: 800,
                  color: axis === 'x' ? '#ef4444' : axis === 'y' ? '#10b981' : '#3b82f6',
                  width: '14px',
                }}
              >
                {axis.toUpperCase()}
              </span>
              <button
                onClick={() => handleNudgeRot(axis, -1)}
                style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', fontSize: '10px', fontWeight: 700, cursor: 'pointer' }}
              >
                -{buildManager.rotateSnap || 15}°
              </button>
              <button
                onClick={() => handleNudgeRot(axis, 1)}
                style={{ padding: '4px 8px', borderRadius: '4px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', fontSize: '10px', fontWeight: 700, cursor: 'pointer' }}
              >
                +{buildManager.rotateSnap || 15}°
              </button>
            </div>
          ))}
        </div>
      )}

      {transformMode === 'scale' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <button
            onClick={() => handleNudgeScale(-1)}
            style={{ padding: '6px 10px', borderRadius: '6px', backgroundColor: 'rgba(255, 255, 255, 0.08)', color: '#ffffff', border: 'none', cursor: 'pointer' }}
            title="Scale Down"
          >
            <Minus size={16} />
          </button>
          <button
            onClick={() => handleNudgeScale(1)}
            style={{ padding: '6px 10px', borderRadius: '6px', backgroundColor: 'rgba(0, 162, 255, 0.3)', color: '#ffffff', border: '1px solid rgba(0, 162, 255, 0.5)', cursor: 'pointer' }}
            title="Scale Up"
          >
            <Plus size={16} />
          </button>
        </div>
      )}
    </div>
  );
};
