import React, { useState, useEffect, useCallback } from 'react';
import { Flame, Shield, Zap, Sparkles, Sword, Rocket, Crosshair, Orbit, Wind, Plane } from 'lucide-react';
import { audioSystem } from '../game/AudioSystem';

export interface CombatButtonsProps {
  onAttack: () => boolean;
  onAbility?: (id: number) => boolean;
  onDash?: () => boolean;
  onToggleFlight?: () => boolean;
  isFlying?: boolean;
  powerSet?: 'classic' | 'ironman' | 'agatha';
  isClashActive?: boolean;
}

interface AbilityState {
  id: number;
  name: string;
  icon: React.ReactNode;
  cooldownTotal: number;
  cooldownRemaining: number;
}

const getInitialAbilities = (powerSet: 'classic' | 'ironman' | 'agatha'): AbilityState[] => {
  if (powerSet === 'agatha') {
    return [
      { id: 1, name: 'Drenagem Sombria', icon: <Zap size={19} className="text-purple-300" />, cooldownTotal: 8.0, cooldownRemaining: 0 },
      { id: 2, name: 'Passo das Sombras', icon: <Rocket size={19} className="text-violet-300" />, cooldownTotal: 4.5, cooldownRemaining: 0 },
      { id: 3, name: 'Voo Arcano', icon: <Plane size={19} className="text-fuchsia-300" />, cooldownTotal: 2.0, cooldownRemaining: 0 },
      { id: 4, name: 'Estrangulamento Arcano', icon: <Crosshair size={19} className="text-pink-400" />, cooldownTotal: 9.0, cooldownRemaining: 0 },
    ];
  }

  if (powerSet === 'ironman') {
    return [
      { id: 1, name: 'Missile Volley', icon: <Rocket size={19} className="text-amber-400" />, cooldownTotal: 6.0, cooldownRemaining: 0 },
      { id: 2, name: 'Dual Beam & Clash', icon: <Flame size={19} className="text-red-400" />, cooldownTotal: 10.0, cooldownRemaining: 0 },
      { id: 3, name: 'Unibeam Blast', icon: <Crosshair size={19} className="text-yellow-400" />, cooldownTotal: 8.0, cooldownRemaining: 0 },
      { id: 4, name: 'Spinning Lasers', icon: <Orbit size={19} className="text-cyan-400" />, cooldownTotal: 12.0, cooldownRemaining: 0 },
    ];
  }

  return [
    { id: 1, name: 'Flame Burst', icon: <Flame size={19} className="text-amber-400" />, cooldownTotal: 4.0, cooldownRemaining: 0 },
    { id: 2, name: 'Shield Ward', icon: <Shield size={19} className="text-cyan-400" />, cooldownTotal: 6.0, cooldownRemaining: 0 },
    { id: 3, name: 'Thunder Shock', icon: <Zap size={19} className="text-yellow-300" />, cooldownTotal: 3.5, cooldownRemaining: 0 },
    { id: 4, name: 'Arcane Nova', icon: <Sparkles size={19} className="text-purple-400" />, cooldownTotal: 5.0, cooldownRemaining: 0 },
  ];
};

export const CombatButtons: React.FC<CombatButtonsProps> = ({
  onAttack,
  onAbility,
  onDash,
  onToggleFlight,
  isFlying = false,
  powerSet = 'ironman',
  isClashActive = false,
}) => {
  const [attackCooldown, setAttackCooldown] = useState(0);
  const [dashCooldown, setDashCooldown] = useState(0);
  const [isAttackPressed, setIsAttackPressed] = useState(false);
  const [abilities, setAbilities] = useState<AbilityState[]>(() => getInitialAbilities(powerSet));

  // Sync abilities when powerSet changes
  useEffect(() => {
    setAbilities(getInitialAbilities(powerSet));
    setAttackCooldown(0);
  }, [powerSet]);

  // Tick cooldowns
  useEffect(() => {
    let last = performance.now();
    const interval = setInterval(() => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;

      setAttackCooldown((prev) => Math.max(0, prev - dt));
      setDashCooldown((prev) => Math.max(0, prev - dt));
      setAbilities((prev) =>
        prev.map((ab) => ({
          ...ab,
          cooldownRemaining: Math.max(0, ab.cooldownRemaining - dt),
        }))
      );
    }, 30);

    return () => clearInterval(interval);
  }, []);

  const handleAttackPress = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();

    // Beam Clash bypasses cooldown to allow rapid tapping!
    if (!isClashActive && attackCooldown > 0) return;

    setIsAttackPressed(true);
    const launched = onAttack();
    if (launched && !isClashActive) {
      setAttackCooldown(powerSet === 'agatha' ? 0.22 : powerSet === 'ironman' ? 0.20 : 0.42);
    }
  }, [attackCooldown, isClashActive, onAttack, powerSet]);

  const handleAttackRelease = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsAttackPressed(false);
  }, []);

  const handleAbilityPress = useCallback((id: number, e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const ab = abilities.find((a) => a.id === id);
    if (!ab || ab.cooldownRemaining > 0) return;

    audioSystem.playUiClick();
    const launched = onAbility ? onAbility(id) : true;
    if (launched) {
      setAbilities((prev) =>
        prev.map((a) => (a.id === id ? { ...a, cooldownRemaining: a.cooldownTotal } : a))
      );
    }
  }, [abilities, onAbility]);

  const handleDashPress = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (dashCooldown > 0) return;
    const launched = onDash ? onDash() : false;
    if (launched) {
      setDashCooldown(2.2);
    }
  }, [dashCooldown, onDash]);

  const handleFlightPress = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onToggleFlight) {
      onToggleFlight();
    }
  }, [onToggleFlight]);

  // Arc parameters strictly in upper-left quadrant (↖️ ⬅️ ⬆️) from Attack button
  const ATTACK_CX = 206;
  const ATTACK_CY = 166;
  const ORBIT_RADIUS = 76;
  const angles = [-6, 28, 62, 96];

  const maxAttackCd = powerSet === 'agatha' ? 0.22 : powerSet === 'ironman' ? 0.20 : 0.42;

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 'max(16px, env(safe-area-inset-bottom, 16px))',
        right: 'max(16px, env(safe-area-inset-right, 16px))',
        width: '260px',
        height: '220px',
        pointerEvents: 'none',
        zIndex: 50,
        userSelect: 'none',
        WebkitUserSelect: 'none',
        touchAction: 'none',
      }}
    >
      {/* Flight Mode Toggle Button (Iron Man & Agatha Harkness) */}
      {(powerSet === 'ironman' || powerSet === 'agatha') && (
        <div
          onPointerDown={handleFlightPress}
          style={{
            position: 'absolute',
            left: '60px',
            top: '86px',
            width: '44px',
            height: '44px',
            borderRadius: '50%',
            background: isFlying
              ? powerSet === 'agatha'
                ? 'radial-gradient(circle at 35% 35%, #7e22ce, #3b0764)'
                : 'radial-gradient(circle at 35% 35%, #0284c7, #075985)'
              : 'radial-gradient(circle at 35% 35%, #232c3d, #111722)',
            border: isFlying
              ? powerSet === 'agatha'
                ? '2px solid #c084fc'
                : '2px solid #38bdf8'
              : '1.5px solid rgba(255, 255, 255, 0.22)',
            boxShadow: isFlying
              ? powerSet === 'agatha'
                ? '0 0 16px rgba(168, 85, 247, 0.75), 0 3px 8px rgba(0,0,0,0.45)'
                : '0 0 16px rgba(56, 189, 248, 0.75), 0 3px 8px rgba(0,0,0,0.45)'
              : '0 3px 8px rgba(0,0,0,0.4)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            pointerEvents: 'auto',
            cursor: 'pointer',
            transition: 'all 0.15s ease',
          }}
          className="active:scale-90"
          title={isFlying ? (powerSet === 'agatha' ? 'Descer (Pousar)' : 'Land') : (powerSet === 'agatha' ? 'Voo Arcano (Levitar)' : 'Flight')}
        >
          <Plane size={19} className={isFlying ? (powerSet === 'agatha' ? 'text-fuchsia-200 drop-shadow' : 'text-sky-200 drop-shadow') : 'text-slate-300'} />
          <span style={{ fontSize: '7.5px', fontWeight: 800, color: isFlying ? (powerSet === 'agatha' ? '#f3e8ff' : '#bae6fd') : '#94a3b8', letterSpacing: '0.04em' }}>
            {isFlying ? (powerSet === 'agatha' ? 'LEVITANDO' : 'FLYING') : (powerSet === 'agatha' ? 'VOO ARC.' : 'FLIGHT')}
          </span>
        </div>
      )}

      {/* Thruster Dash / Passo das Sombras Button */}
      <div
        onPointerDown={handleDashPress}
        style={{
          position: 'absolute',
          left: '60px',
          top: '144px',
          width: '44px',
          height: '44px',
          borderRadius: '50%',
          background: dashCooldown > 0
            ? 'radial-gradient(circle at 35% 35%, #23272e, #12151a)'
            : powerSet === 'agatha'
            ? 'radial-gradient(circle at 35% 35%, #6b21a8, #2e1065)'
            : 'radial-gradient(circle at 35% 35%, #d97706, #78350f)',
          border: dashCooldown > 0
            ? '1.5px solid rgba(255, 255, 255, 0.18)'
            : powerSet === 'agatha'
            ? '2px solid rgba(192, 132, 252, 0.9)'
            : '2px solid rgba(251, 191, 36, 0.85)',
          boxShadow: dashCooldown > 0
            ? '0 2px 6px rgba(0,0,0,0.4)'
            : powerSet === 'agatha'
            ? '0 3px 12px rgba(168, 85, 247, 0.5), 0 0 10px rgba(192, 132, 252, 0.4)'
            : '0 3px 12px rgba(245, 158, 11, 0.45), 0 0 8px rgba(251, 191, 36, 0.3)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          pointerEvents: 'auto',
          cursor: dashCooldown > 0 ? 'not-allowed' : 'pointer',
          overflow: 'hidden',
          transition: 'all 0.12s ease',
        }}
        className="active:scale-90"
        title={powerSet === 'agatha' ? 'Passo das Sombras (Teleporte)' : 'Thruster Dash / Evade'}
      >
        {/* Radial Cooldown */}
        {dashCooldown > 0 && (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              borderRadius: '50%',
              background: `conic-gradient(rgba(0, 0, 0, 0.65) ${(dashCooldown / 2.2) * 100}%, transparent ${(dashCooldown / 2.2) * 100}%)`,
              pointerEvents: 'none',
            }}
          />
        )}
        <Wind size={19} className={dashCooldown > 0 ? 'text-slate-500' : powerSet === 'agatha' ? 'text-purple-200' : 'text-amber-200'} />
        <span
          style={{
            fontSize: '7.5px',
            fontWeight: 800,
            color: dashCooldown > 0 ? '#94a3b8' : powerSet === 'agatha' ? '#f3e8ff' : '#fef3c7',
            letterSpacing: '0.04em',
            zIndex: 2,
          }}
        >
          {dashCooldown > 0 ? dashCooldown.toFixed(1) : powerSet === 'agatha' ? 'PASSO' : 'DASH'}
        </span>
      </div>

      {/* Four Ability Buttons in Upper-Left Quadrant Arc (↖️ ⬅️ ⬆️) */}
      {abilities.map((ab, idx) => {
        const rad = (angles[idx] * Math.PI) / 180;
        const x = ATTACK_CX - ORBIT_RADIUS * Math.cos(rad);
        const y = ATTACK_CY - ORBIT_RADIUS * Math.sin(rad);
        const onCd = ab.cooldownRemaining > 0;
        const cdPct = onCd ? (ab.cooldownRemaining / ab.cooldownTotal) * 100 : 0;

        return (
          <div
            key={ab.id}
            onPointerDown={(e) => handleAbilityPress(ab.id, e)}
            style={{
              position: 'absolute',
              left: `${x - 19}px`,
              top: `${y - 19}px`,
              width: '38px',
              height: '38px',
              borderRadius: '50%',
              background: onCd
                ? 'radial-gradient(circle at 35% 35%, #2a2d33, #16181b)'
                : powerSet === 'agatha'
                ? 'radial-gradient(circle at 35% 35%, #4c1d95, #1e0933)'
                : powerSet === 'ironman'
                ? 'radial-gradient(circle at 35% 35%, #3d2a1d, #1a1412)'
                : 'radial-gradient(circle at 35% 35%, #343a46, #1b1e24)',
              border: onCd
                ? '1.5px solid rgba(255, 255, 255, 0.15)'
                : powerSet === 'agatha'
                ? '1.5px solid rgba(192, 132, 252, 0.75)'
                : powerSet === 'ironman'
                ? '1.5px solid rgba(245, 158, 11, 0.55)'
                : '1.5px solid rgba(255, 255, 255, 0.45)',
              boxShadow: onCd
                ? '0 2px 6px rgba(0, 0, 0, 0.4)'
                : powerSet === 'agatha'
                ? '0 3px 10px rgba(0, 0, 0, 0.35), 0 0 10px rgba(168, 85, 247, 0.4)'
                : powerSet === 'ironman'
                ? '0 3px 10px rgba(0, 0, 0, 0.35), 0 0 8px rgba(245, 158, 11, 0.25)'
                : '0 3px 10px rgba(0, 0, 0, 0.35), 0 0 8px rgba(255, 255, 255, 0.08)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              pointerEvents: 'auto',
              cursor: onCd ? 'not-allowed' : 'pointer',
              overflow: 'hidden',
              transition: 'transform 0.1s ease, filter 0.15s ease',
            }}
            className="active:scale-90"
            title={ab.name}
          >
            {/* Radial Cooldown Overlay */}
            {onCd && (
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  borderRadius: '50%',
                  background: `conic-gradient(rgba(0, 0, 0, 0.75) ${cdPct}%, transparent ${cdPct}%)`,
                  pointerEvents: 'none',
                }}
              />
            )}

            <div style={{ position: 'relative', zIndex: 2, opacity: onCd ? 0.4 : 1 }}>
              {ab.icon}
            </div>

            {/* Cooldown Text */}
            {onCd && (
              <span
                style={{
                  position: 'absolute',
                  zIndex: 3,
                  fontSize: '9.5px',
                  fontWeight: 700,
                  color: '#ffffff',
                  textShadow: '0 1px 3px rgba(0,0,0,0.85)',
                }}
              >
                {ab.cooldownRemaining.toFixed(1)}
              </span>
            )}
          </div>
        );
      })}

      {/* Main ATTACK Button (80px) */}
      <div
        onPointerDown={handleAttackPress}
        onPointerUp={handleAttackRelease}
        onPointerCancel={handleAttackRelease}
        style={{
          position: 'absolute',
          left: `${ATTACK_CX - 40}px`,
          top: `${ATTACK_CY - 40}px`,
          width: '80px',
          height: '80px',
          borderRadius: '50%',
          background: isClashActive
            ? 'radial-gradient(circle at 35% 35%, #991b1b, #450a0a)'
            : isAttackPressed
            ? 'radial-gradient(circle at 35% 35%, #1f2b38, #0e1620)'
            : powerSet === 'agatha'
            ? 'radial-gradient(circle at 35% 35%, #581c87, #1e0933)'
            : powerSet === 'ironman'
            ? 'radial-gradient(circle at 35% 35%, #7f1d1d, #2b0b0b)'
            : 'radial-gradient(circle at 35% 35%, #2c3e50, #16202c)',
          border: isClashActive
            ? '3px solid #f59e0b'
            : attackCooldown > 0
            ? '2.5px solid rgba(255, 255, 255, 0.25)'
            : powerSet === 'agatha'
            ? '2.5px solid rgba(192, 132, 252, 0.95)'
            : powerSet === 'ironman'
            ? '2.5px solid rgba(239, 68, 68, 0.9)'
            : '2.5px solid rgba(72, 202, 228, 0.85)',
          boxShadow: isClashActive
            ? '0 0 24px rgba(245, 158, 11, 0.7), 0 0 8px #ef4444'
            : isAttackPressed
            ? powerSet === 'agatha'
              ? '0 2px 8px rgba(0, 0, 0, 0.5), 0 0 16px rgba(168, 85, 247, 0.55)'
              : '0 2px 8px rgba(0, 0, 0, 0.5), 0 0 16px rgba(239, 68, 68, 0.45)'
            : powerSet === 'agatha'
            ? '0 6px 20px rgba(0, 0, 0, 0.45), 0 0 22px rgba(168, 85, 247, 0.5)'
            : powerSet === 'ironman'
            ? '0 6px 20px rgba(0, 0, 0, 0.45), 0 0 18px rgba(239, 68, 68, 0.35)'
            : '0 6px 20px rgba(0, 0, 0, 0.45), 0 0 22px rgba(72, 202, 228, 0.35)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          pointerEvents: 'auto',
          cursor: 'pointer',
          overflow: 'hidden',
          transform: isAttackPressed ? 'scale(0.92)' : 'scale(1)',
          transition: 'transform 0.08s ease, border-color 0.15s ease, box-shadow 0.15s ease',
        }}
      >
        {/* Radial Cooldown sweep */}
        {!isClashActive && attackCooldown > 0 && (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              borderRadius: '50%',
              background: `conic-gradient(rgba(0, 0, 0, 0.65) ${(attackCooldown / maxAttackCd) * 100}%, transparent ${(attackCooldown / maxAttackCd) * 100}%)`,
              pointerEvents: 'none',
            }}
          />
        )}

        <div style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          {isClashActive ? (
            <Zap size={28} className="text-amber-300 animate-pulse drop-shadow-sm" />
          ) : powerSet === 'agatha' ? (
            <Sparkles size={28} className="text-purple-300 drop-shadow-sm" />
          ) : powerSet === 'ironman' ? (
            <Zap size={28} className="text-red-300 drop-shadow-sm" />
          ) : (
            <Sword size={28} className="text-cyan-300 drop-shadow-sm" />
          )}
          <span
            style={{
              fontSize: isClashActive ? '11px' : '9px',
              fontWeight: 800,
              letterSpacing: '0.08em',
              color: isClashActive ? '#fef08a' : powerSet === 'agatha' ? '#f3e8ff' : '#fecaca',
              marginTop: '2px',
            }}
          >
            {isClashActive ? 'PUSH!' : powerSet === 'agatha' ? 'RAJADA' : 'ATTACK'}
          </span>
        </div>
      </div>
    </div>
  );
};
