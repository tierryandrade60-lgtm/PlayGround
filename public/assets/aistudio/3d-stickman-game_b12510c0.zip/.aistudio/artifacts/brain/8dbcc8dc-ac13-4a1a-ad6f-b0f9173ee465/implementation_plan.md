# Iron Man 3D Game: Visual Polish, Hit-Stop & Graphics Settings

Enhance visual fidelity, combat feedback (hit-stop), energy charging animations, impact effects, and scalable graphics quality settings.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following preferences have been confirmed via interactive selection:
> - **Default Mobile Graphics Quality**: Balanced medium quality (optimized particles, lighting, shadows, and performance).
> - **Charging Energy Buildup Intensity**: Vibrant energy aura around hands and weapons during heavy ability preparation.

- **Confirmed Decision 1**: Implement 40-70 ms hit-stop on powerful confirmed impacts (heavy missiles, major hits) without freezing player controls, camera, or simulation.
- **Confirmed Decision 2**: Connect Low, Medium, and High graphics settings directly to Three.js rendering parameters (shadow map enabled/disabled, particle counts, light/bloom complexity) without altering gameplay mechanics, damage, or collision.

## 1. Overview & Core Concept

- **What It Does**: Adds polished combat feedback (brief hit-stop), visual charging buildup with glowing energy auras and synchronized audio/visuals, distinct visual identities for repulsors, missiles, and beams, and functional Low/Medium/High graphics quality presets.
- **Target Audience**: Players seeking an immersive, high-performance mobile-friendly Iron Man combat experience.
- **Key Value**: Delivers professional impact feel and scalable visual performance across devices.

## 2. User Experience & Visual Design

- **Key User Flows**: 
  1. Charging heavy abilities displays a vibrant energy aura and glowing particle buildup around hands/weapons.
  2. Confirming heavy hits triggers a satisfying 50ms hit-stop freeze frame on the target while keeping smooth camera and joystick control.
  3. Adjusting graphics quality in settings instantly updates shadow maps, particle density, and lighting complexity.
- **Visual Identity & Theme**: Cinematic sci-fi metallic HUD, vibrant energy effects (cyan/red/gold), and clean mobile-friendly HUD elements.

## 3. Key Product Decisions & Trade-Offs

- **Decision 1**: Hit-stop implemented via transient time-scale freeze or target animation pause.
  - *Chosen Approach*: Brief pause (50ms) on target reaction and impact position while player controls remain active.
  - *Why*: Gives heavy impact weight without sluggish input response.
- **Decision 2**: Graphics quality presets.
  - *Chosen Approach*: Dynamic toggle of renderer shadow map settings, max particle counts, and lighting update frequency.
  - *Why*: Ensures smooth mobile gameplay while offering crisp visuals on high-end devices.

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                    GameScene / App State                    │
│  - Settings Manager (Graphics Quality: Low / Medium / High) │
└──────────────┬──────────────────────────────┬───────────────┘
               │                              │
               ▼                              ▼
┌──────────────────────────────┐┌─────────────────────────────┐
│    IronManAbilities.ts       ││        GameEffects.ts       │
│  - Energy Charging Buildup   ││  - Hit-Stop Manager         │
│  - Vibrant Hand Auras        ││  - Scalable Particle Emitters│
│  - Distinct Projectiles      ││  - Explosion & Impact FX    │
└──────────────────────────────┘└─────────────────────────────┘
```
